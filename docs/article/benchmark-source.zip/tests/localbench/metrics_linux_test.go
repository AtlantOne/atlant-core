package main

import "testing"

func TestUDPCountersAndReset(t *testing.T) {
	a := parseUDPCounters("Udp: InDatagrams RcvbufErrors SndbufErrors\nUdp: 100 2 1\n")
	b := parseUDPCounters("Udp: InDatagrams RcvbufErrors SndbufErrors\nUdp: 120 3 1\n")
	d := udpCounterDelta(a, b)
	if d["InDatagrams"] != 20 || d["RcvbufErrors"] != 1 || d["SndbufErrors"] != 0 {
		t.Fatal(d)
	}
	if udpCounterDelta(nil, b) != nil {
		t.Fatal("unavailable counters represented as zero")
	}
	if _, ok := udpCounterDelta(b, a)["InDatagrams"]; ok {
		t.Fatal("counter reset underflow")
	}
	if parseUDPCounters("Udp: One Two\nUdp: 1\n") != nil {
		t.Fatal("malformed counters accepted")
	}
}
