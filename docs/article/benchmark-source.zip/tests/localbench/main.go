// Local-only benchmark of real client/server implementations. No WAN targets,
// system proxy changes, OS TUN adapters, or host routing changes are used.
package main

import (
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"hash/crc32"
	"io"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/net/http2"
	"golang.org/x/net/proxy"
)

const blockSize = 64 * 1024
const batchSize = 4 * 1024 * 1024
const benchmarkServerName = "bench.example.test"

var payload = make([]byte, blockSize)
var crcTable = crc32.MakeTable(crc32.Castagnoli)
var expectedCRC uint32
var benchmarkProtection bool
var benchmarkDisablePacer bool
var benchmarkQUICProcesses = 1
var benchmarkProtocolFilter string
var benchmarkWireVersion = 2
var benchmarkServerPort int
var benchmarkServerHost = "127.0.0.1"
var benchmarkClientHost = "127.0.0.1"
var benchmarkServerNamespace, benchmarkClientNamespace string

type managed struct {
	cmd *exec.Cmd
	log *os.File
}
type row struct {
	UDPCounters  map[string]uint64 `json:"udp_namespace_counter_delta,omitempty"`
	Protocol     string            `json:"protocol"`
	InnerTLS     bool              `json:"inner_tls"`
	Streams      int               `json:"streams"`
	Direction    string            `json:"direction"`
	Round        int               `json:"round"`
	Bytes        int64             `json:"bytes"`
	Seconds      float64           `json:"seconds"`
	Mbps         float64           `json:"mbps"`
	SetupMS      float64           `json:"setup_ms"`
	RTTMedianMS  float64           `json:"rtt_median_ms"`
	CPUSeconds   float64           `json:"cpu_seconds"`
	AverageCores float64           `json:"average_cpu_cores"`
	RSSMiB       float64           `json:"rss_mib_at_end"`
	Error        string            `json:"error,omitempty"`
}
type report struct {
	UDPBufferLimits                  map[string]uint64 `json:"udp_buffer_limits,omitempty"`
	QUICClientProcesses              int               `json:"quic_client_processes"`
	WireVersion                      int               `json:"atlant_wire_version,omitempty"`
	TargetHost                       string            `json:"target_host,omitempty"`
	DisablePacer                     bool              `json:"atlant_disable_pacer"`
	Protection                       bool              `json:"protection_enabled"`
	ExcludedResults                  []row             `json:"excluded_startup_results,omitempty"`
	SupplementPaths                  []string          `json:"supplement_paths,omitempty"`
	Started                          string            `json:"started"`
	OS, Arch, GoVersion, XrayVersion string
	CPUs                             int
	DurationSeconds                  float64
	BatchBytes                       int
	Notes                            []string
	Results                          []row
}
type profile struct {
	name, socks string
	socksList   []string
	pids        []int
	cleanup     func()
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func writeAll(w io.Writer, p []byte) error {
	for len(p) > 0 {
		n, e := w.Write(p)
		if e != nil {
			return e
		}
		if n == 0 {
			return io.ErrShortWrite
		}
		p = p[n:]
	}
	return nil
}
func writeJSON(path string, v any) {
	b, e := json.MarshalIndent(v, "", "  ")
	must(e)
	must(os.WriteFile(path, b, 0600))
}
func port() int {
	l, e := net.Listen("tcp", "127.0.0.1:0")
	must(e)
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port
}
func addr(p int) string { return net.JoinHostPort("127.0.0.1", strconv.Itoa(p)) }
func launch(dir, name, binary string, args ...string) managed {
	f, e := os.Create(filepath.Join(dir, name+".log"))
	must(e)
	namespace := ""
	if name == "server" {
		namespace = benchmarkServerNamespace
	}
	if name == "client" || name == "client-relay" {
		namespace = benchmarkClientNamespace
	}
	if namespace != "" {
		args = append([]string{"-t", namespace, "-n", "--", binary}, args...)
		binary = "nsenter"
	}
	cmd := exec.Command(binary, args...)
	cmd.Dir = dir
	cmd.Stdout = f
	cmd.Stderr = f
	must(cmd.Start())
	return managed{cmd, f}
}
func (p managed) stop() { _ = p.cmd.Process.Kill(); _ = p.cmd.Wait(); _ = p.log.Close() }
func waitPort(p int) error {
	return waitAddress(addr(p))
}
func waitAddress(address string) error {
	deadline := time.Now().Add(8 * time.Second)
	for time.Now().Before(deadline) {
		c, e := net.DialTimeout("tcp", address, 500*time.Millisecond)
		if e == nil {
			c.Close()
			return nil
		}
		time.Sleep(50 * time.Millisecond)
	}
	return fmt.Errorf("listener %s not ready", address)
}

func serveTarget(l net.Listener) {
	for {
		c, e := l.Accept()
		if e != nil {
			return
		}
		go handleTarget(c)
	}
}
func handleTarget(c net.Conn) {
	defer c.Close()
	buf := make([]byte, blockSize)
	for {
		_ = c.SetDeadline(time.Now().Add(30 * time.Second))
		var command [9]byte
		if _, e := io.ReadFull(c, command[:]); e != nil {
			return
		}
		size := int64(binary.BigEndian.Uint64(command[1:]))
		if size < 0 || size > batchSize {
			return
		}
		if command[0] == 'P' {
			if _, e := io.ReadFull(c, buf[:64]); e != nil {
				return
			}
			if writeAll(c, buf[:64]) != nil {
				return
			}
			continue
		}
		hash := uint32(0)
		switch command[0] {
		case 'D':
			for left := size; left > 0; {
				n := min(int64(len(payload)), left)
				if writeAll(c, payload[:n]) != nil {
					return
				}
				left -= n
			}
			hash = expectedCRC
		case 'U':
			for left := size; left > 0; {
				n := min(int64(len(buf)), left)
				if _, e := io.ReadFull(c, buf[:n]); e != nil {
					return
				}
				hash = crc32.Update(hash, crcTable, buf[:n])
				left -= n
			}
		default:
			return
		}
		var ack [12]byte
		binary.BigEndian.PutUint64(ack[:8], uint64(size))
		binary.BigEndian.PutUint32(ack[8:], hash)
		if writeAll(c, ack[:]) != nil {
			return
		}
	}
}
func transfer(c net.Conn, op byte, buf []byte) error {
	var command [9]byte
	command[0] = op
	binary.BigEndian.PutUint64(command[1:], batchSize)
	if e := writeAll(c, command[:]); e != nil {
		return e
	}
	crc := uint32(0)
	for left := batchSize; left > 0; left -= len(buf) {
		if op == 'D' {
			if _, e := io.ReadFull(c, buf); e != nil {
				return e
			}
			crc = crc32.Update(crc, crcTable, buf)
		} else {
			if e := writeAll(c, payload); e != nil {
				return e
			}
		}
	}
	var ack [12]byte
	if _, e := io.ReadFull(c, ack[:]); e != nil {
		return e
	}
	if binary.BigEndian.Uint64(ack[:8]) != batchSize || binary.BigEndian.Uint32(ack[8:]) != expectedCRC {
		return fmt.Errorf("receiver byte count/CRC mismatch")
	}
	if op == 'D' && crc != expectedCRC {
		return fmt.Errorf("download CRC mismatch")
	}
	return nil
}
func dial(socks, target string, inner bool, roots *x509.CertPool) (net.Conn, error) {
	var c net.Conn
	var e error
	d := &net.Dialer{Timeout: 8 * time.Second}
	if socks == "" {
		c, e = d.Dial("tcp", target)
	} else {
		var sd proxy.Dialer
		sd, e = proxy.SOCKS5("tcp", socks, nil, d)
		if e == nil {
			c, e = sd.Dial("tcp", target)
		}
	}
	if e != nil {
		return nil, e
	}
	_ = c.SetDeadline(time.Now().Add(10 * time.Second))
	if inner {
		t := tls.Client(c, &tls.Config{RootCAs: roots, ServerName: "localhost", MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13})
		if e = t.Handshake(); e != nil {
			c.Close()
			return nil, e
		}
		c = t
	}
	return c, nil
}
func measure(p profile, target string, inner bool, roots *x509.CertPool, streams, round int, op byte, duration time.Duration) (r row) {
	r = row{Protocol: p.name, InnerTLS: inner, Streams: streams, Round: round, Direction: string(op)}
	udpBefore := readUDPCounters()
	defer func() { r.UDPCounters = udpCounterDelta(udpBefore, readUDPCounters()) }()
	conns := make([]net.Conn, 0, streams)
	defer func() {
		for _, c := range conns {
			c.Close()
		}
	}()
	setup := time.Now()
	for i := range streams {
		socks := p.socks
		if len(p.socksList) > 0 {
			socks = p.socksList[i%len(p.socksList)]
		}
		c, e := dial(socks, target, inner, roots)
		if e != nil {
			r.Error = e.Error()
			return r
		}
		conns = append(conns, c)
	}
	r.SetupMS = float64(time.Since(setup).Microseconds()) / 1000
	for _, c := range conns {
		if e := transfer(c, op, make([]byte, blockSize)); e != nil {
			r.Error = "warmup: " + e.Error()
			return r
		}
	}
	lat := []float64{}
	var ping [73]byte
	ping[0] = 'P'
	copy(ping[9:], payload[:64])
	var pong [64]byte
	for range 31 {
		start := time.Now()
		if e := writeAll(conns[0], ping[:]); e != nil {
			r.Error = e.Error()
			return r
		}
		if _, e := io.ReadFull(conns[0], pong[:]); e != nil {
			r.Error = e.Error()
			return r
		}
		lat = append(lat, float64(time.Since(start).Nanoseconds())/1e6)
	}
	sort.Float64s(lat)
	r.RTTMedianMS = lat[len(lat)/2]
	var wg sync.WaitGroup
	var mu sync.Mutex
	beforeCPU, _ := processStats(p.pids)
	start := time.Now()
	end := start.Add(duration)
	for _, c := range conns {
		wg.Add(1)
		go func(c net.Conn) {
			defer wg.Done()
			buf := make([]byte, blockSize)
			var count int64
			var err error
			_ = c.SetDeadline(time.Now().Add(duration + 20*time.Second))
			for time.Now().Before(end) {
				if err = transfer(c, op, buf); err != nil {
					break
				}
				count += batchSize
			}
			mu.Lock()
			r.Bytes += count
			if err != nil {
				r.Error = err.Error()
			}
			mu.Unlock()
		}(c)
	}
	wg.Wait()
	r.Seconds = time.Since(start).Seconds()
	r.Mbps = float64(r.Bytes) * 8 / r.Seconds / 1e6
	afterCPU, rss := processStats(p.pids)
	r.CPUSeconds = afterCPU - beforeCPU
	r.AverageCores = r.CPUSeconds / r.Seconds
	r.RSSMiB = rss
	if p.name == "wireguard-kernel" {
		r.CPUSeconds = -1
		r.AverageCores = -1
		r.RSSMiB = -1
	} // procfs omits kernel worker costs
	return r
}

func main() {
	server := flag.String("server", "", "Atlant server binary")
	client := flag.String("client", "", "Atlant Linux client binary")
	xray := flag.String("xray", "", "official Xray binary")
	output := flag.String("out", "localbench-results", "new output directory")
	seconds := flag.Float64("seconds", 2, "minimum seconds per throughput sample")
	rounds := flag.Int("rounds", 3, "repeat count")
	roundStart := flag.Int("round-start", 1, "first round number, for explicit infrastructure retries")
	filter := flag.String("only", "", "optional single protocol")
	protection := flag.Bool("protection", true, "retain Atlant padding and chaffing during measurements")
	disablePacer := flag.Bool("disable-pacer", false, "explicit opt-in to disable Atlant QUIC pacing; default matches production")
	quicProcesses := flag.Int("quic-client-processes", 1, "diagnostic: 1 shared or 4 independent QUIC client processes; not a production pool")
	targetHost := flag.String("target-host", "127.0.0.1", "RAM target bind IP; use 198.18.0.1 in isolated benchmark namespace")
	helper := flag.Bool("serve-helper", false, "internal kernel-WG target process")
	patternFile := flag.String("payload-file", "", "internal RAM pattern input")
	certFile := flag.String("cert-file", "", "internal TLS certificate")
	keyFile := flag.String("key-file", "", "internal TLS key")
	plainPort := flag.Int("plain-port", 0, "internal plain target port")
	tlsPort := flag.Int("tls-port", 0, "internal TLS target port")
	summary := flag.String("summarize", "", "write REPORT.md beside a results.json file")
	mergeBase := flag.String("merge-base", "", "original report for an explicit startup retry")
	mergeExtra := flag.String("merge-extra", "", "supplement with successfully retried round")
	mergeOut := flag.String("merge-out", "", "combined report output")
	impaired := flag.String("impairment", "", "isolated WAN emulation scenario; uses separate client/server network namespaces")
	impairedStreams := flag.Int("impairment-streams", 4, "bulk flow count for isolated impairment tests (1 or 4)")
	impairedPipeline := flag.Bool("impairment-pipeline", false, "pipeline bulk requests instead of waiting for each 64KiB acknowledgement")
	flag.Parse()
	if value := os.Getenv("ATLANT_BENCH_WIRE_VERSION"); value != "" {
		v, err := strconv.Atoi(value)
		must(err)
		if v != 2 && v != 3 && v != 4 && v != 6 && v != 7 {
			panic("unsupported benchmark wire version")
		}
		benchmarkWireVersion = v
	}
	benchmarkProtection = *protection
	benchmarkDisablePacer = *disablePacer
	if *quicProcesses != 1 && *quicProcesses != 4 {
		panic("quic-client-processes must be 1 or 4")
	}
	if *quicProcesses != 1 && *impaired != "" {
		panic("independent QUIC processes are supported only in loopback diagnostics")
	}
	benchmarkQUICProcesses = *quicProcesses
	benchmarkProtocolFilter = *filter
	if *impaired != "" {
		must(runImpairment(*impaired, *output, *server, *client, *xray, *seconds, *rounds, *impairedStreams, *impairedPipeline))
		return
	}
	if *mergeBase != "" {
		must(mergeReports(*mergeBase, *mergeExtra, *mergeOut))
		return
	}
	if *summary != "" {
		must(summarize(*summary))
		return
	}
	if *helper {
		runTargetHelper(*targetHost, *plainPort, *tlsPort, *patternFile, *certFile, *keyFile)
		return
	}
	must(os.MkdirAll(*output, 0700))
	out, e := filepath.Abs(*output)
	must(e)
	_, e = rand.Read(payload)
	must(e)
	must(os.WriteFile(filepath.Join(out, "test-payload.bin"), payload, 0600))
	for range batchSize / blockSize {
		expectedCRC = crc32.Update(expectedCRC, crcTable, payload)
	}
	private, e := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	must(e)
	certTemplate := &x509.Certificate{SerialNumber: big.NewInt(1), DNSNames: []string{"localhost", benchmarkServerName}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(24 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}, BasicConstraintsValid: true}
	der, e := x509.CreateCertificate(rand.Reader, certTemplate, certTemplate, &private.PublicKey, private)
	must(e)
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyDER, e := x509.MarshalPKCS8PrivateKey(private)
	must(e)
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER})
	certPath, keyPath := filepath.Join(out, "test-cert.pem"), filepath.Join(out, "test-key.pem")
	must(os.WriteFile(certPath, certPEM, 0600))
	must(os.WriteFile(keyPath, keyPEM, 0600))
	roots := x509.NewCertPool()
	roots.AppendCertsFromPEM(certPEM)
	certificate, e := tls.X509KeyPair(certPEM, keyPEM)
	must(e)
	plain, e := net.Listen("tcp", net.JoinHostPort(*targetHost, "0"))
	must(e)
	defer plain.Close()
	go serveTarget(plain)
	secure, e := tls.Listen("tcp", net.JoinHostPort(*targetHost, "0"), &tls.Config{Certificates: []tls.Certificate{certificate}, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13})
	must(e)
	defer secure.Close()
	go serveTarget(secure)
	donor, e := net.Listen("tcp", "127.0.0.1:0")
	must(e)
	defer donor.Close()
	donorServer := &http.Server{TLSConfig: &tls.Config{Certificates: []tls.Certificate{certificate}, MinVersion: tls.VersionTLS13}, Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })}
	must(http2.ConfigureServer(donorServer, &http2.Server{}))
	go donorServer.ServeTLS(donor, "", "")
	defer donorServer.Close()
	xrayVersion := "not available"
	if *xray != "" {
		b, _ := exec.Command(*xray, "version").Output()
		xrayVersion = string(b)
	}
	rep := report{Started: time.Now().Format(time.RFC3339), OS: runtime.GOOS, Arch: runtime.GOARCH, GoVersion: runtime.Version(), CPUs: runtime.NumCPU(), XrayVersion: xrayVersion, DurationSeconds: *seconds, BatchBytes: batchSize, Notes: []string{"Loopback only; data generated and checked in RAM; CRC32C and receiver counts verified.", "Setup/handshake and warmup excluded from throughput. 1/4 streams, upload/download, clear and inner TLS1.3 payload.", "VLESS raw is UNENCRYPTED reference, not equivalent security.", "WireGuard is real wireguard-go with gVisor userspace TCP stacks, NOT kernel WireGuard.", "No simulated WAN delay/loss; not an Internet performance or censorship test."}}
	rep.Protection = benchmarkProtection
	rep.UDPBufferLimits = udpBufferLimits()
	rep.QUICClientProcesses = benchmarkQUICProcesses
	rep.WireVersion, rep.TargetHost, rep.DisablePacer = benchmarkWireVersion, *targetHost, benchmarkDisablePacer
	names := []string{"direct", "atlant-reality", "atlant-xhttp", "atlant-quic", "vless-raw", "vless-tls", "vless-reality-vision", "vless-xhttp-reality", "vless-xhttp-tls", "wireguard-go", "wireguard-kernel"}
	for round := *roundStart; round < *roundStart+*rounds; round++ {
		// Rotate protocol order between rounds to reduce thermal/order bias.
		for i := range names {
			name := names[(i+round-1)%len(names)]
			if *filter != "" && !strings.Contains(","+*filter+",", ","+name+",") {
				continue
			}
			p, err := startProfile(name, out, *server, *client, *xray, donor.Addr().String(), certPath, keyPath, plain.Addr().String(), secure.Addr().String())
			if err != nil {
				fmt.Printf("%s START ERROR: %v\n", name, err)
				rep.Results = append(rep.Results, row{Protocol: name, Round: round, Error: err.Error()})
				writeJSON(filepath.Join(out, "results.json"), rep)
				continue
			}
			for _, inner := range []bool{false, true} {
				target := plain.Addr().String()
				if inner {
					target = secure.Addr().String()
				}
				for _, streams := range []int{1, 4} {
					for _, op := range []byte{'D', 'U'} {
						r := measure(p, target, inner, roots, streams, round, op, time.Duration(*seconds*1e9))
						rep.Results = append(rep.Results, r)
						fmt.Printf("r%d %-23s TLS=%v n=%d %c %8.1f Mbps RTT=%6.3f ms err=%s\n", round, name, inner, streams, op, r.Mbps, r.RTTMedianMS, r.Error)
						writeJSON(filepath.Join(out, "results.json"), rep)
					}
				}
			}
			p.cleanup()
		}
	}
	for _, result := range rep.Results {
		if result.Error != "" {
			os.Exit(1)
		}
	}
}

func startProfile(name, out, server, client, xray, donor, certPath, keyPath, plain, secure string) (profile, error) {
	if name == "direct" {
		return profile{name: name, pids: []int{os.Getpid()}, cleanup: func() {}}, nil
	}
	if name == "wireguard-go" {
		return startWireGuard(name, plain, secure)
	}
	if name == "wireguard-kernel" {
		return startKernelWireGuard(out, certPath, keyPath, plain, secure)
	}
	work, e := os.MkdirTemp(out, name+"-")
	if e != nil {
		return profile{}, e
	}
	sp, cp := port(), port()
	if benchmarkServerPort != 0 {
		sp = benchmarkServerPort
	}
	serverAddress := net.JoinHostPort(benchmarkServerHost, strconv.Itoa(sp))
	cleanup := func() {}
	p := profile{name: name, socks: net.JoinHostPort(benchmarkClientHost, strconv.Itoa(cp))}
	if name == "atlant-reality" || name == "atlant-xhttp" || name == "atlant-quic" {
		if server == "" || client == "" {
			return p, fmt.Errorf("Atlant binaries missing")
		}
		key := make([]byte, 32)
		_, e = rand.Read(key)
		if e != nil {
			return p, e
		}
		keyHex := hex.EncodeToString(key)
		static, e := ecdh.X25519().GenerateKey(rand.Reader)
		if e != nil {
			return p, e
		}
		staticPath := filepath.Join(work, "static.key")
		must(os.WriteFile(staticPath, static.Bytes(), 0600))
		users := filepath.Join(work, "users.json")
		writeJSON(users, map[string]any{"version": 1, "users": map[string]any{"bench": map[string]any{"name": "bench", "pbk": keyHex, "enabled": true}}})
		conf := filepath.Join(work, "server.json")
		apiAddress := net.JoinHostPort("127.0.0.1", strconv.Itoa(port()))
		writeJSON(conf, map[string]any{"listen": serverAddress, "sni": benchmarkServerName, "users_file": users, "server_key_file": staticPath, "wire_version": benchmarkWireVersion, "legacy_wire": benchmarkWireVersion == 2, "log_level": "error", "api_addr": apiAddress, "api_secret": keyHex, "quic": map[string]any{"disable_pacer": benchmarkDisablePacer}})
		srv := launch(work, "server", server, "-c", conf)
		cleanup = srv.stop
		if e = waitAddress(serverAddress); e != nil {
			cleanup()
			return p, e
		}
		transport := map[string]string{"atlant-reality": "reality", "atlant-xhttp": "xhttp", "atlant-quic": "quic"}[name]
		cc := filepath.Join(work, "client.json")
		clientConfig := map[string]any{"server": serverAddress, "sni": benchmarkServerName, "pbk": keyHex, "user": "bench", "local": p.socks, "transport": transport, "tcp_proto": transport, "wire_version": benchmarkWireVersion, "server_pub_key": hex.EncodeToString(static.PublicKey().Bytes()), "log_level": "error", "fake_dns": false, "traffic_padding": benchmarkProtection, "padding_enabled": benchmarkProtection, "chaffing_enabled": benchmarkProtection, "min_padding": 32, "max_padding": 256, "chaffing_interval": 10, "mux": false, "path": "/api/v1/sync", "mode": "stream"}
		coreSOCKS := p.socks
		if benchmarkClientNamespace != "" {
			coreSOCKS = addr(port())
			clientConfig["local"] = coreSOCKS
		}

		writeJSON(cc, clientConfig)
		if probe := os.Getenv("ATLANT_BENCH_ANDROID_PROBE"); probe != "" && name == "atlant-quic" && benchmarkWireVersion == 7 {
			cmd := exec.Command(probe, "-test.run=^TestLiveDirectQUICNoTCP$", "-test.v", "-test.timeout=20s")
			cmd.Env = append(os.Environ(), "ATLANT_TEST_CONFIG="+cc)
			output, err := cmd.CombinedOutput()
			if err != nil {
				cleanup()
				return p, fmt.Errorf("Android direct QUIC probe: %w: %s", err, output)
			}
			fmt.Print(string(output))
		}
		cli := launch(work, "client", client, "-c", cc)
		p.cleanup = func() { cli.stop(); srv.stop() }
		if benchmarkClientNamespace != "" {
			relay := launch(work, "client-relay", "python3", "-u", "-c", namespaceSOCKSRelay, p.socks, coreSOCKS)
			p.cleanup = func() { relay.stop(); cli.stop(); srv.stop() }
		}
		p.pids = []int{os.Getpid(), srv.cmd.Process.Pid, cli.cmd.Process.Pid}
		if name == "atlant-quic" && benchmarkQUICProcesses > 1 {
			clients := []managed{cli}
			p.socksList = []string{p.socks}
			for i := 1; i < benchmarkQUICProcesses; i++ {
				endpoint := addr(port())
				clientConfig["local"] = endpoint
				path := filepath.Join(work, fmt.Sprintf("client-%d.json", i))
				writeJSON(path, clientConfig)
				child := launch(work, fmt.Sprintf("quic-client-%d", i), client, "-c", path)
				clients = append(clients, child)
				p.pids = append(p.pids, child.cmd.Process.Pid)
				p.socksList = append(p.socksList, endpoint)
			}
			p.cleanup = func() {
				for _, child := range clients {
					child.stop()
				}
				srv.stop()
			}
			for _, endpoint := range p.socksList {
				if err := waitAddress(endpoint); err != nil {
					p.cleanup()
					return p, err
				}
			}
		}
	} else {
		if xray == "" {
			return p, fmt.Errorf("Xray binary missing")
		}
		uid := "b831381d-6324-4d53-ad4f-8cda48b30811"
		security := "none"
		flow := ""
		ss, cs := map[string]any{"network": "raw", "security": "none"}, map[string]any{"network": "raw", "security": "none"}
		if name == "vless-tls" || name == "vless-xhttp-tls" {
			security = "tls"
			ss["tlsSettings"] = map[string]any{"certificates": []any{map[string]any{"certificateFile": certPath, "keyFile": keyPath}}}
			certData, err := os.ReadFile(certPath)
			if err != nil {
				return p, err
			}
			block, _ := pem.Decode(certData)
			if block == nil {
				return p, fmt.Errorf("bad test certificate")
			}
			fingerprint := sha256.Sum256(block.Bytes)
			cs["tlsSettings"] = map[string]any{"serverName": benchmarkServerName, "pinnedPeerCertSha256": hex.EncodeToString(fingerprint[:]), "fingerprint": "chrome"}
		}
		if name == "vless-reality-vision" || name == "vless-xhttp-reality" {
			security = "reality"
			flow = "xtls-rprx-vision"
			k, e := ecdh.X25519().GenerateKey(rand.Reader)
			if e != nil {
				return p, e
			}
			ss["realitySettings"] = map[string]any{"target": donor, "dest": donor, "serverNames": []string{benchmarkServerName}, "privateKey": base64.RawURLEncoding.EncodeToString(k.Bytes()), "shortIds": []string{"1234abcd"}}
			cs["realitySettings"] = map[string]any{"serverName": benchmarkServerName, "fingerprint": "chrome", "password": base64.RawURLEncoding.EncodeToString(k.PublicKey().Bytes()), "publicKey": base64.RawURLEncoding.EncodeToString(k.PublicKey().Bytes()), "shortId": "1234abcd"}
		}
		ss["security"] = security
		cs["security"] = security
		if strings.HasPrefix(name, "vless-xhttp-") {
			flow = ""
			ss["network"] = "xhttp"
			cs["network"] = "xhttp"
			ss["xhttpSettings"] = map[string]any{"path": "/api/v1/sync/", "mode": "stream-one"}
			cs["xhttpSettings"] = map[string]any{"path": "/api/v1/sync/", "mode": "stream-one"}
		}
		sc := filepath.Join(work, "server.json")
		cc := filepath.Join(work, "client.json")
		writeJSON(sc, map[string]any{"log": map[string]any{"loglevel": "error"}, "inbounds": []any{map[string]any{"listen": benchmarkServerHost, "port": sp, "protocol": "vless", "settings": map[string]any{"clients": []any{map[string]any{"id": uid, "flow": flow}}, "decryption": "none"}, "streamSettings": ss}}, "outbounds": []any{map[string]any{"protocol": "freedom"}}})
		writeJSON(cc, map[string]any{"log": map[string]any{"loglevel": "error"}, "inbounds": []any{map[string]any{"listen": benchmarkClientHost, "port": cp, "protocol": "socks", "settings": map[string]any{"auth": "noauth", "udp": false}}}, "outbounds": []any{map[string]any{"protocol": "vless", "settings": map[string]any{"vnext": []any{map[string]any{"address": benchmarkServerHost, "port": sp, "users": []any{map[string]any{"id": uid, "encryption": "none", "flow": flow}}}}}, "streamSettings": cs}}})
		srv := launch(work, "server", xray, "run", "-c", sc)
		cleanup = srv.stop
		if e = waitAddress(serverAddress); e != nil {
			cleanup()
			return p, e
		}
		cli := launch(work, "client", xray, "run", "-c", cc)
		p.cleanup = func() { cli.stop(); srv.stop() }
		p.pids = []int{os.Getpid(), srv.cmd.Process.Pid, cli.cmd.Process.Pid}
	}
	if e = waitAddress(p.socks); e != nil {
		p.cleanup()
		return p, e
	}
	return p, nil
}

const namespaceSOCKSRelay = `import socket,socketserver,sys,threading,time
def endpoint(value):
 host,port=value.rsplit(':',1);return host,int(port)
for attempt in range(100):
 try:
  connection=socket.create_connection(endpoint(sys.argv[2]),timeout=.2);connection.close();break
 except OSError: time.sleep(.05)
else: raise SystemExit('isolated loopback SOCKS listener did not become ready')
class Relay(socketserver.BaseRequestHandler):
 def handle(self):
  remote=socket.create_connection(endpoint(sys.argv[2]),timeout=5);remote.settimeout(None)
  def copy(source,destination):
   try:
    while True:
     data=source.recv(65536)
     if not data: break
     destination.sendall(data)
   except OSError: pass
   try: destination.shutdown(socket.SHUT_WR)
   except OSError: pass
  worker=threading.Thread(target=copy,args=(self.request,remote),daemon=True);worker.start()
  copy(remote,self.request);worker.join(timeout=5);remote.close()
class Server(socketserver.ThreadingTCPServer):
 allow_reuse_address=True
 daemon_threads=True
Server(endpoint(sys.argv[1]),Relay).serve_forever()
`
