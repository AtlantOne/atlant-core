"""Validate the complete article run and export public, credential-free tables."""
import argparse
import csv
import itertools
import json
from pathlib import Path
import statistics


NAMES = {
    'direct': 'Без VPN (ориентир стенда)',
    'atlant-reality': 'Atlant TCP',
    'atlant-xhttp': 'Atlant XHTTP',
    'atlant-quic': 'Atlant QUIC',
    'vless-reality-vision': 'VLESS + REALITY + Vision',
    'vless-xhttp-reality': 'VLESS XHTTP + REALITY',
}


def validate(report):
    expected = set(itertools.product(NAMES, (False, True), (1, 4), ('D', 'U'), (1, 2, 3)))
    actual = []
    for row in report['Results']:
        actual.append((row['protocol'], row['inner_tls'], row['streams'], row['direction'], row['round']))
        if row.get('error') or row['bytes'] <= 0 or row['seconds'] < 2 or row['mbps'] <= 0:
            raise ValueError('Incomplete or unsuccessful sample; do not publish a success-only subset')
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError('Expected all 144 samples, exactly once')
    if report['DurationSeconds'] != 2 or not report['protection_enabled'] or report['atlant_disable_pacer'] or report['quic_client_processes'] != 1:
        raise ValueError('Unexpected benchmark settings')


def values(report, protocol, inner, streams, direction, field='mbps'):
    return [r[field] for r in report['Results'] if (r['protocol'], r['inner_tls'], r['streams'], r['direction']) == (protocol, inner, streams, direction)]


def table(report, inner):
    result = [
        '| Реализация | Скачать, 1 поток | Отправить, 1 поток | Скачать, 4 потока | Отправить, 4 потока |',
        '|---|---:|---:|---:|---:|',
    ]
    for name, title in NAMES.items():
        cells = []
        for streams, direction in itertools.product((1, 4), ('D', 'U')):
            samples = values(report, name, inner, streams, direction)
            cells.append(f'{statistics.median(samples):.0f} [{min(samples):.0f}–{max(samples):.0f}]')
        result.append('| ' + title + ' | ' + ' | '.join(cells) + ' |')
    return '\n'.join(result)


def export(source, destination):
    report = json.loads(source.read_text(encoding='utf-8'))
    validate(report)
    destination.mkdir(parents=True, exist_ok=True)
    for name in ('BENCHMARKS_HABR_RU.md', 'benchmark-samples.csv', 'benchmark-summary.csv'):
        if (destination / name).exists():
            raise ValueError('Choose a new output directory; do not overwrite a previous report')
    fields = ['protocol', 'inner_tls', 'streams', 'direction', 'round', 'mbps', 'bytes', 'seconds', 'rtt_median_ms', 'average_cpu_cores', 'rss_mib_at_end']
    with (destination / 'benchmark-samples.csv').open('x', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(report['Results'])
    summary = []
    for protocol, inner, streams, direction in itertools.product(NAMES, (False, True), (1, 4), ('D', 'U')):
        samples = values(report, protocol, inner, streams, direction)
        summary.append(dict(protocol=protocol, inner_tls=inner, streams=streams, direction=direction,
                            median_mbps=statistics.median(samples), min_mbps=min(samples), max_mbps=max(samples)))
    with (destination / 'benchmark-summary.csv').open('x', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, summary[0].keys())
        writer.writeheader()
        writer.writerows(summary)
    gib = sum(row['bytes'] for row in report['Results']) / 2**30
    text = f'''# Локальные измерения для статьи об Atlant

Дата: 24 октября 2026. Проверены все 144 результата, ошибок передачи нет.
CRC-подтверждённая полезная нагрузка без прогрева: {gib:.2f} GiB.

Стенд: Intel Core i5-10210U, 4 ядра / 8 логических CPU, Linux/amd64 в WSL2.
Atlant: опубликованный core-коммит ddefeffb45cfcd31f13cf2a73ad187e57a317a5f,
{report['GoVersion']}. Xray: {report['XrayVersion'].splitlines()[0]}.

Каждый замер минимум 2 секунды; три повтора с ротацией порядка участников.
Данные проходят настоящие сервер/клиент через SOCKS; цель в RAM.
Партии 4 MiB, блоки 64 KiB; проверяются число байт и CRC32C.
Handshake, прогрев и RTT-пробы не входят в throughput.
Включены настройки padding/chaffing Atlant, pacing не отключён; один QUIC-клиент.
Защита адресов сервера не отключалась. Все участники используют одно тестовое SNI.
Служебные конфиги и журналы остаются на диске, но полезные данные — в RAM.

## С внутренним TLS 1.3

Мбит/с; медиана [минимум–максимум]. Это модель TLS-нагрузки, не браузерный тест.

{table(report, True)}

## Без внутреннего TLS

Внешняя защита VPN остаётся включённой. Мбит/с; медиана [минимум–максимум].

{table(report, False)}

## Границы измерения

Локальный throughput — не скорость Интернета, не Android TUN и не проверка DPI.
Фоновые приложения не отключались, частоты CPU не фиксировались. Публикуются все
повторы и диапазоны, а не лучшие результаты. Различия компиляторов сохранены.
XHTTP Xray использует stream-one; результаты не распространяются на все его режимы.
Hysteria 2 в этот запуск не включена. Нешифрованный VLESS RAW не использовался.
Сборки завершены до начала замеров. Тесты не выполнялись параллельно друг с другом.

Первая попытка с устаревшим SNI localhost и попытка без локального DNS донора
не считаются производительностью Atlant. Их файлы сохранены отдельно; после
исправления только стенда повторена вся матрица, а не выгодные отдельные строки.
Основные маршруты Windows/WSL, чужие VPN и VDS не изменялись.
'''
    (destination / 'BENCHMARKS_HABR_RU.md').write_text(text, encoding='utf-8')
    print(json.dumps({'samples': len(report['Results']), 'errors': 0, 'verified_gib': gib, 'summary': summary}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    export(args.source, args.destination)
