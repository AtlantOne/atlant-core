package main

import (
	"crypto/tls"
	"fmt"
	"hash/crc32"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"time"

	"golang.zx2c4.com/wireguard/wgctrl"
	"golang.zx2c4.com/wireguard/wgctrl/wgtypes"
)

func runTargetHelper(host string, pp, tp int, pattern, cert, key string) {
	b, e := os.ReadFile(pattern)
	must(e)
	if len(b) != blockSize {
		panic("invalid test pattern")
	}
	copy(payload, b)
	for range batchSize / blockSize {
		expectedCRC = crc32.Update(expectedCRC, crcTable, payload)
	}
	pair, e := tls.LoadX509KeyPair(cert, key)
	must(e)
	plain, e := net.Listen("tcp", net.JoinHostPort(host, strconv.Itoa(pp)))
	must(e)
	defer plain.Close()
	go serveTarget(plain)
	secure, e := tls.Listen("tcp", net.JoinHostPort(host, strconv.Itoa(tp)), &tls.Config{Certificates: []tls.Certificate{pair}, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13})
	must(e)
	defer secure.Close()
	serveTarget(secure)
}

func command(binary string, args ...string) error {
	b, e := exec.Command(binary, args...).CombinedOutput()
	if e != nil {
		return fmt.Errorf("%s %v: %w: %s", binary, args, e, b)
	}
	return nil
}

func startKernelWireGuard(out, cert, key, plain, secure string) (profile, error) {
	// Both interfaces are created in this already-isolated namespace. WG UDP
	// sockets retain their birth namespace when the server interface is moved.
	// No veth, host interfaces, public sockets or external routes are needed.
	keeper := exec.Command("unshare", "-n", "--", "sleep", "600")
	if e := keeper.Start(); e != nil {
		return profile{}, e
	}
	ns := strconv.Itoa(keeper.Process.Pid)
	clientName := "awgc" + ns
	serverName := "awgs" + ns
	clientCreated, serverCreated, moved := false, false, false
	var helper *managed
	var socks net.Listener
	cleanup := func() {
		if clientCreated {
			if stats, e := wgctrl.New(); e == nil {
				if dev, e := stats.Device(clientName); e == nil {
					proof := []map[string]any{}
					for _, peer := range dev.Peers {
						proof = append(proof, map[string]any{"last_handshake": peer.LastHandshakeTime, "receive_bytes": peer.ReceiveBytes, "transmit_bytes": peer.TransmitBytes})
					}
					writeJSON(filepath.Join(out, "kernel-proof-"+ns+".json"), map[string]any{"device": dev.Name, "type": dev.Type.String(), "peers": proof})
				}
				stats.Close()
			}
		}
		if socks != nil {
			socks.Close()
		}
		if helper != nil {
			helper.stop()
		}
		if clientCreated {
			_ = command("ip", "link", "del", "dev", clientName)
		}
		if serverCreated {
			if moved {
				_ = command("nsenter", "-t", ns, "-n", "--", "ip", "link", "del", "dev", serverName)
			} else {
				_ = command("ip", "link", "del", "dev", serverName)
			}
		}
		_ = keeper.Process.Kill()
		_ = keeper.Wait()
	}
	fail := func(e error) (profile, error) { cleanup(); return profile{}, e }
	time.Sleep(50 * time.Millisecond)
	if e := command("ip", "link", "add", clientName, "type", "wireguard"); e != nil {
		return fail(e)
	}
	clientCreated = true
	if e := command("ip", "link", "add", serverName, "type", "wireguard"); e != nil {
		return fail(e)
	}
	serverCreated = true
	wc, e := wgctrl.New()
	if e != nil {
		return fail(e)
	}
	defer wc.Close()
	ck, e := wgtypes.GeneratePrivateKey()
	if e != nil {
		return fail(e)
	}
	sk, e := wgtypes.GeneratePrivateKey()
	if e != nil {
		return fail(e)
	}
	cp, sp := udpPort(), udpPort()
	_, cnet, _ := net.ParseCIDR("10.78.0.1/32")
	_, snet, _ := net.ParseCIDR("10.78.0.2/32")
	cc := wgtypes.Config{PrivateKey: &ck, ListenPort: &cp, Peers: []wgtypes.PeerConfig{{PublicKey: sk.PublicKey(), Endpoint: &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: sp}, AllowedIPs: []net.IPNet{*snet}}}}
	sc := wgtypes.Config{PrivateKey: &sk, ListenPort: &sp, Peers: []wgtypes.PeerConfig{{PublicKey: ck.PublicKey(), Endpoint: &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: cp}, AllowedIPs: []net.IPNet{*cnet}}}}
	if e = wc.ConfigureDevice(clientName, cc); e != nil {
		return fail(e)
	}
	if e = wc.ConfigureDevice(serverName, sc); e != nil {
		return fail(e)
	}
	if e = command("ip", "link", "set", "dev", serverName, "up"); e != nil {
		return fail(e)
	}
	if e = command("ip", "link", "set", "dev", serverName, "netns", ns); e != nil {
		return fail(e)
	}
	moved = true
	nscommand := func(args ...string) error {
		return command("nsenter", append([]string{"-t", ns, "-n", "--", "ip"}, args...)...)
	}
	for _, args := range [][]string{{"link", "set", "lo", "up"}, {"address", "add", "10.78.0.2/32", "dev", serverName}, {"link", "set", "dev", serverName, "mtu", "1420", "up"}, {"route", "add", "10.78.0.1/32", "dev", serverName}} {
		if e = nscommand(args...); e != nil {
			return fail(e)
		}
	}
	for _, args := range [][]string{{"address", "add", "10.78.0.1/32", "dev", clientName}, {"link", "set", "dev", clientName, "mtu", "1420", "up"}, {"route", "add", "10.78.0.2/32", "dev", clientName}} {
		if e = command("ip", args...); e != nil {
			return fail(e)
		}
	}
	_, pp, _ := net.SplitHostPort(plain)
	_, tp, _ := net.SplitHostPort(secure)
	exe, e := os.Executable()
	if e != nil {
		return fail(e)
	}
	h := launch(out, "kernel-target", "nsenter", "-t", ns, "-n", "--", exe, "-serve-helper", "-target-host", "10.78.0.2", "-plain-port", pp, "-tls-port", tp, "-payload-file", filepath.Join(out, "test-payload.bin"), "-cert-file", cert, "-key-file", key)
	helper = &h
	var c net.Conn
	readyDeadline := time.Now().Add(8 * time.Second)
	for time.Now().Before(readyDeadline) {
		c, e = net.DialTimeout("tcp", net.JoinHostPort("10.78.0.2", pp), time.Second)
		if e == nil {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	if e != nil {
		return fail(e)
	}
	c.Close()
	socks, e = net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		return fail(e)
	}
	go func() {
		for {
			c, e := socks.Accept()
			if e != nil {
				return
			}
			go func() {
				defer c.Close()
				target, e := socksRequest(c)
				if e != nil || (target != plain && target != secure) {
					return
				}
				_, pt, _ := net.SplitHostPort(target)
				dst, e := net.DialTimeout("tcp", net.JoinHostPort("10.78.0.2", pt), 5*time.Second)
				if e != nil {
					return
				}
				defer dst.Close()
				if writeAll(c, []byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0}) != nil {
					return
				}
				bridge(c, dst)
			}()
		}
	}()
	return profile{name: "wireguard-kernel", socks: socks.Addr().String(), pids: []int{os.Getpid(), h.cmd.Process.Pid}, cleanup: cleanup}, nil
}
