"""Export the complete preselected channel matrix, not a winning subset."""
import argparse
import csv
import itertools
import json
from pathlib import Path
import statistics

from article_report import NAMES

PROTOCOLS = {key: value for key, value in NAMES.items() if key != 'direct'}
SCENARIOS = ('clean', 'rtt50-loss1', 'rtt100-loss3')


def export(root, destination):
    reports = {}
    samples = []
    pings = []
    for name in SCENARIOS:
        report = json.loads((root / ('channel-' + name) / 'results.json').read_text(encoding='utf-8'))
        expected = set(itertools.product(PROTOCOLS, (1, 2), ('D', 'U')))
        actual = [(r['protocol'], r['round'], r['direction']) for r in report['results']]
        if len(actual) != len(expected) or set(actual) != expected:
            raise ValueError('Expected all 20 samples exactly once: ' + name)
        if report['measurement_version'] != 3 or not report['protection_requested'] or report['scenario']['rate_mbps_per_direction'] != 20:
            raise ValueError('Unexpected scenario configuration')
        reports[name] = report
        for row in report['results']:
            if row.get('errors') or row['crc_verified_bytes'] <= 0 or not row['loaded_pings'] or row['bulk_streams'] != 4:
                raise ValueError('A sample failed; preserve the failure rather than exporting only successful rows')
            sample = dict(scenario=name, protocol=row['protocol'], round=row['round'], direction=row['direction'],
                          mbps=row['mbps'], p50_ms=row['loaded_rtt_p50_ms'], p95_ms=row['loaded_rtt_p95_ms'], p99_ms=row['loaded_rtt_p99_ms'],
                          crc_verified_bytes=row['crc_verified_bytes'], seconds=row['seconds'], ping_count=len(row['loaded_pings']),
                          ping_timeouts=row['ping_timeouts'], cold_first_response_ms=row['cold_first_response_ms'])
            samples.append(sample)
            for ping in row['loaded_pings']:
                pings.append(dict(scenario=name, protocol=row['protocol'], round=row['round'], direction=row['direction'], **ping))
    summaries = []
    for scenario, protocol, direction in itertools.product(SCENARIOS, PROTOCOLS, ('D', 'U')):
        group = [r for r in samples if (r['scenario'], r['protocol'], r['direction']) == (scenario, protocol, direction)]
        summaries.append(dict(scenario=scenario, protocol=protocol, direction=direction,
                              mbps=statistics.median(r['mbps'] for r in group), p95_ms=statistics.median(r['p95_ms'] for r in group),
                              min_p95_ms=min(r['p95_ms'] for r in group), max_p95_ms=max(r['p95_ms'] for r in group)))
    destination.mkdir(parents=True, exist_ok=True)
    for name, rows in [('channel-samples.csv', samples), ('channel-pings.csv', pings), ('channel-summary.csv', summaries)]:
        with (destination / name).open('x', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    tables = []
    for scenario in SCENARIOS:
        table = [f'## {scenario}', '', '| Реализация | Goodput D/U, Мбит/с | p95 под нагрузкой D/U, мс |', '|---|---:|---:|']
        for protocol, title in PROTOCOLS.items():
            group = {r['direction']: r for r in summaries if r['scenario'] == scenario and r['protocol'] == protocol}
            table.append(f"| {title} | {group['D']['mbps']:.2f} / {group['U']['mbps']:.2f} | {group['D']['p95_ms']:.0f} / {group['U']['p95_ms']:.0f} |")
        tables.append('\n'.join(table))
    mib = sum(r['crc_verified_bytes'] for r in samples) / 2**20
    timeouts = sum(r['ping_timeouts'] for r in samples)
    text = f'''# Atlant и Xray: ограниченный канал и отзывчивость

24 октября 2026. Полная матрица: 60 успешных окон измерения, 0 ошибок,
{mib:.2f} MiB CRC-подтверждённых данных, {len(pings)} завершённых echo-проб.

Канал 20 Мбит/с в каждом направлении. Clean: без заданных задержек/потерь;
rtt50-loss1: задержка 25 мс + jitter 2 мс и потери 1% в каждом направлении;
rtt100-loss3: задержка 50 мс + jitter 5 мс и потери 3% в каждом направлении.
Очередь 256 пакетов, MTU 1500, GSO/GRO/TSO off только на временных veth.
Netem действует на forwarded tunnel-пакеты, а не egress TCP-отправителя.

Настоящие клиенты и серверы в двух отдельных child network namespaces.
Третий временный namespace содержит маршрутизатор, RAM-цель и локальный
TLS/HTTP2-донор для Xray REALITY. Внешнего Интернета нет. Узлы используют одно SNI.
Сборки Atlant те же, что в RAM-тесте; Xray 26.3.27. Для расширения сравнения
изменён только стенд, не код VPN. На основном хосте маршруты/DNS/VPN не менялись.

Каждое окно — 8 секунд, два повтора каждого направления, новые процессы/сессии.
4 bulk-потока + отдельный echo-поток. Pipeline: до 16 неподтверждённых блоков
64 KiB на поток. Учёт только после CRC/ACK; конечные незавершённые блоки не входят.
Внутреннего TLS нет. Защитные настройки Atlant включены, pacing не отключён.
TCP mux=false: независимые внешние TCP-соединения; QUIC использует общую сессию.
Это поведение данных конфигураций, не равенство числа congestion controllers.

Значения в таблицах — медианы двух повторов. Для задержки это **медиана p95
отдельных окон**, а не p95 объединённых проб и не доверительный интервал.
Пограничные таймауты при завершении окна сохранены в CSV: всего {timeouts}.
Ранние таймауты считаются ошибками и не исключаются из удачных серий молча.
Во всех строках есть завершённые echo-пробы; число проб сохранено отдельно.

{chr(10).join(tables)}

Все три сценария и оба направления выбраны до просмотра результатов.
Скорость, отзывчивость, стоимость CPU и скрытность — разные свойства.
Данный тест не подтверждает браузерную неотличимость или работу на всех сетях.
Короткие окна и два повтора не заменяют длительные полевые испытания;
полные p95 по повторам, goodput и исходные echo-пробы приложены в CSV.
Hysteria 2 здесь не измерялась.
'''
    (destination / 'CHANNEL_BENCHMARKS_RU.md').write_text(text, encoding='utf-8')
    print(json.dumps(dict(samples=len(samples), errors=0, verified_mib=mib, echo_samples=len(pings), boundary_timeouts=timeouts, summary=summaries), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    export(args.root, args.destination)
