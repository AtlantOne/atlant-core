package main

import (
	"encoding/binary"
	"fmt"
	"hash/crc32"
	"io"
	"net"
	"os"
	"testing"
	"time"
)

func TestImpairmentScenarioAndPercentiles(t *testing.T) {
	for _, name := range []string{"clean", "rtt50-loss1", "rtt100-loss3", "rtt200-loss5", "blackout", "udp-blocked"} {
		cfg, err := impairmentConfig(name)
		if err != nil || cfg.RateMbps != 20 || cfg.QueuePackets != 256 {
			t.Fatalf("%s: %+v %v", name, cfg, err)
		}
	}
	if _, err := impairmentConfig("not-a-scenario"); err == nil {
		t.Fatal("unknown scenario accepted")
	}
	values := []float64{4, 1, 3, 2}
	if impairmentPercentile(values, .5) != 2 || impairmentPercentile(values, .95) != 4 || impairmentPercentile(nil, .95) != 0 {
		t.Fatal("wrong nearest-rank percentiles")
	}
	if values[0] != 4 {
		t.Fatal("percentile changed raw samples")
	}
}

func TestImpairmentBoundaryTimeout(t *testing.T) {
	end := time.Now()
	for _, err := range []error{nil, io.EOF, fmt.Errorf("CRC mismatch")} {
		if impairmentBoundaryTimeout(err, end, end) {
			t.Fatalf("non-timeout censored: %v", err)
		}
	}
	if !impairmentBoundaryTimeout(os.ErrDeadlineExceeded, end, end) {
		t.Fatal("end-window timeout not recognized")
	}
	if impairmentBoundaryTimeout(os.ErrDeadlineExceeded, end, end.Add(-time.Second)) {
		t.Fatal("early timeout censored")
	}
}

func TestImpairmentRejectsBadCRC(t *testing.T) {
	expectedCRC = crc32.Checksum(payload, crcTable)
	client, server := net.Pipe()
	defer client.Close()
	go func() {
		defer server.Close()
		if _, err := io.ReadFull(server, make([]byte, 9+len(payload))); err != nil {
			return
		}
		var ack [12]byte
		binary.BigEndian.PutUint64(ack[:8], uint64(len(payload)))
		binary.BigEndian.PutUint32(ack[8:], expectedCRC^1)
		_ = writeAll(server, ack[:])
	}()
	if err := impairmentChunk(client, 'U', make([]byte, len(payload))); err == nil {
		t.Fatal("bad CRC accepted")
	}
}

func TestImpairmentCRCAndEcho(t *testing.T) {
	for i := range payload {
		payload[i] = byte(i*31 + 7)
	}
	expectedCRC = crc32.Checksum(payload, crcTable)
	for _, op := range []byte{'D', 'U'} {
		client, server := net.Pipe()
		go handleTarget(server)
		if err := impairmentEcho(client); err != nil {
			t.Fatal(err)
		}
		if err := impairmentChunk(client, op, make([]byte, len(payload))); err != nil {
			t.Fatal(err)
		}
		client.Close()
	}
}

func TestImpairmentPipeline(t *testing.T) {
	for i := range payload {
		payload[i] = byte(i*13 + 9)
	}
	expectedCRC = crc32.Checksum(payload, crcTable)
	for _, op := range []byte{'D', 'U'} {
		client, server := net.Pipe()
		go handleTarget(server)
		end := time.Now().Add(250 * time.Millisecond)
		count, err := impairmentPipeline(client, op, end)
		client.Close()
		if count == 0 || count%int64(len(payload)) != 0 {
			t.Fatalf("%c invalid verified count %d", op, count)
		}
		if err != nil && !impairmentBoundaryTimeout(err, end, time.Now()) {
			t.Fatalf("%c: %v", op, err)
		}
	}
}
