package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/net/http2"
)

// The donor lives on the isolated router, reachable from both child namespaces.
// It has no public listener and never contacts an external certificate service.
func startImpairmentDonor(out, host string) (address, certPath, keyPath string, stop func(), err error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return "", "", "", nil, err
	}
	leaf := &x509.Certificate{SerialNumber: big.NewInt(1), DNSNames: []string{benchmarkServerName}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}, BasicConstraintsValid: true}
	der, err := x509.CreateCertificate(rand.Reader, leaf, leaf, &key.PublicKey, key)
	if err != nil {
		return "", "", "", nil, err
	}
	private, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return "", "", "", nil, err
	}
	certPath, keyPath = filepath.Join(out, "donor-cert.pem"), filepath.Join(out, "donor-key.pem")
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: private})
	if err = os.WriteFile(certPath, certPEM, 0600); err != nil {
		return "", "", "", nil, err
	}
	if err = os.WriteFile(keyPath, keyPEM, 0600); err != nil {
		return "", "", "", nil, err
	}
	certificate, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		return "", "", "", nil, err
	}
	listener, err := net.Listen("tcp", net.JoinHostPort(host, "0"))
	if err != nil {
		return "", "", "", nil, err
	}
	server := &http.Server{TLSConfig: &tls.Config{Certificates: []tls.Certificate{certificate}, MinVersion: tls.VersionTLS13}, Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) })}
	if err = http2.ConfigureServer(server, &http2.Server{}); err != nil {
		listener.Close()
		return "", "", "", nil, err
	}
	go server.ServeTLS(listener, "", "")
	return listener.Addr().String(), certPath, keyPath, func() { server.Close() }, nil
}
