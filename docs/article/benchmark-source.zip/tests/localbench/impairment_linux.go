package main

import (
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"golang.org/x/net/proxy"
	"hash/crc32"
	"io"
	"math"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const impairmentPort = 44330

type impairmentScenario struct {
	Name          string `json:"name"`
	OneWayDelayMS int    `json:"one_way_delay_ms"`
	JitterMS      int    `json:"one_way_jitter_ms"`
	LossPercent   int    `json:"loss_percent_per_direction"`
	RateMbps      int    `json:"rate_mbps_per_direction"`
	QueuePackets  int    `json:"queue_limit_packets"`
	Blackout      bool   `json:"blackout_two_seconds"`
	BlockUDP      bool   `json:"block_udp"`
}

func impairmentConfig(name string) (impairmentScenario, error) {
	s := impairmentScenario{Name: name, RateMbps: 20, QueuePackets: 256}
	switch name {
	case "clean":
	case "rtt50-loss1":
		s.OneWayDelayMS = 25
		s.JitterMS = 2
		s.LossPercent = 1
	case "rtt100-loss3":
		s.OneWayDelayMS = 50
		s.JitterMS = 5
		s.LossPercent = 3
	case "rtt200-loss5":
		s.OneWayDelayMS = 100
		s.JitterMS = 10
		s.LossPercent = 5
	case "blackout":
		s.OneWayDelayMS = 50
		s.Blackout = true
	case "udp-blocked":
		s.OneWayDelayMS = 25
		s.BlockUDP = true
	default:
		return s, fmt.Errorf("unknown impairment scenario %q", name)
	}
	return s, nil
}

type impairmentPing struct {
	SentMS float64 `json:"sent_ms_after_load_start"`
	RTTMS  float64 `json:"rtt_ms"`
}
type impairmentOutage struct {
	StartMS float64 `json:"start_ms_after_load_start"`
	EndMS   float64 `json:"end_ms_after_load_start"`
	During  string  `json:"qdisc_during_blackout"`
	Error   string  `json:"error,omitempty"`
}
type impairmentRow struct {
	Protocol    string            `json:"protocol"`
	Round       int               `json:"round"`
	Direction   string            `json:"direction"`
	Streams     int               `json:"bulk_streams"`
	SetupMS     float64           `json:"cold_first_response_ms"`
	UnloadedP50 float64           `json:"unloaded_rtt_p50_ms"`
	LoadedP50   float64           `json:"loaded_rtt_p50_ms"`
	LoadedP95   float64           `json:"loaded_rtt_p95_ms"`
	LoadedP99   float64           `json:"loaded_rtt_p99_ms"`
	Bytes       int64             `json:"crc_verified_bytes"`
	Seconds     float64           `json:"seconds"`
	Mbps        float64           `json:"mbps"`
	CPU         float64           `json:"average_process_cpu_cores"`
	Pings       []impairmentPing  `json:"loaded_pings"`
	Timeouts    int               `json:"ping_timeouts"`
	Errors      []string          `json:"errors,omitempty"`
	Outage      *impairmentOutage `json:"outage,omitempty"`
	RecoveryMS  float64           `json:"first_fresh_echo_after_restore_ms"`
	Recovered   bool              `json:"same_connection_recovered"`
	Qdisc       string            `json:"qdisc_after_measurement"`
}
type impairmentReport struct {
	MeasurementVersion int                `json:"measurement_version"`
	Started            time.Time          `json:"started"`
	Scenario           impairmentScenario `json:"scenario"`
	Protection         bool               `json:"protection_requested"`
	Notes              []string           `json:"notes"`
	Results            []impairmentRow    `json:"results"`
	GoVersion          string             `json:"go_version"`
	XrayVersion        string             `json:"xray_version,omitempty"`
}

func isolatedNetwork() error {
	self, err := os.Readlink("/proc/self/ns/net")
	if err != nil {
		return err
	}
	host, err := os.Readlink("/proc/1/ns/net")
	if err != nil {
		return err
	}
	if self == host {
		return fmt.Errorf("refusing to impair primary network namespace; use unshare -n")
	}
	return nil
}
func impairmentCommand(name string, args ...string) (string, error) {
	data, err := exec.Command(name, args...).CombinedOutput()
	if err != nil {
		return string(data), fmt.Errorf("%s %v: %w: %s", name, args, err, data)
	}
	return string(data), nil
}
func impairmentQdisc() string {
	var result string
	for _, dev := range []string{"bench-c", "bench-s"} {
		s, err := impairmentCommand("tc", "-s", "-j", "qdisc", "show", "dev", dev)
		result += dev + ": " + s
		if err != nil {
			result += err.Error()
		}
	}
	return result
}
func impairmentLeaf(dev string, s impairmentScenario, blackout bool, seed int) error {
	args := []string{"qdisc", "replace", "dev", dev, "parent", "1:3", "handle", "30:", "netem", "limit", strconv.Itoa(s.QueuePackets)}
	if blackout {
		args = append(args, "loss", "100%")
	} else {
		args = append(args, "delay", fmt.Sprintf("%dms", s.OneWayDelayMS))
		if s.JitterMS > 0 {
			args = append(args, fmt.Sprintf("%dms", s.JitterMS), "distribution", "normal")
		}
		args = append(args, "loss", "random", fmt.Sprintf("%d%%", s.LossPercent), "rate", fmt.Sprintf("%dmbit", s.RateMbps), "seed", strconv.Itoa(seed))
	}
	_, err := impairmentCommand("tc", args...)
	return err
}
func configureImpairment(s impairmentScenario, seed int) error {
	if err := isolatedNetwork(); err != nil {
		return err
	}
	for _, dev := range []string{"bench-c", "bench-s"} {
		// Replacing a root of the same kind can retain child qdiscs and their
		// queues/counters. Reset only our explicitly owned root in the private ns.
		state, err := impairmentCommand("tc", "-j", "qdisc", "show", "dev", dev)
		if err != nil {
			return err
		}
		var roots []struct {
			Kind   string `json:"kind"`
			Handle string `json:"handle"`
			Root   bool   `json:"root"`
		}
		if err = json.Unmarshal([]byte(state), &roots); err != nil {
			return err
		}
		for _, root := range roots {
			if !root.Root {
				continue
			}
			if root.Kind == "prio" && root.Handle == "1:" {
				if _, err = impairmentCommand("tc", "qdisc", "del", "dev", dev, "root"); err != nil {
					return err
				}
			} else if root.Kind != "noqueue" {
				return fmt.Errorf("unexpected root qdisc on private %s; refusing to replace it", dev)
			}
		}
		if _, err := impairmentCommand("tc", "qdisc", "add", "dev", dev, "root", "handle", "1:", "prio", "bands", "3", "priomap", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"); err != nil {
			return err
		}
		if err := impairmentLeaf(dev, s, false, seed); err != nil {
			return err
		}
		if s.BlockUDP {
			if _, err := impairmentCommand("tc", "qdisc", "replace", "dev", dev, "parent", "1:2", "handle", "20:", "netem", "loss", "100%"); err != nil {
				return err
			}
		}
		portField := "sport"
		if dev == "bench-s" {
			portField = "dport"
		}
		for _, protocol := range []string{"6", "17"} {
			flow := "1:3"
			if s.BlockUDP && protocol == "17" {
				flow = "1:2"
			}
			if _, err := impairmentCommand("tc", "filter", "add", "dev", dev, "protocol", "ip", "parent", "1:", "prio", "1", "u32", "match", "ip", "protocol", protocol, "0xff", "match", "ip", portField, strconv.Itoa(impairmentPort), "0xffff", "flowid", flow); err != nil {
				return err
			}
		}
	}
	return nil
}
func impairmentPercentile(values []float64, p float64) float64 {
	if len(values) == 0 {
		return 0
	}
	a := append([]float64(nil), values...)
	sort.Float64s(a)
	i := int(math.Ceil(float64(len(a))*p)) - 1
	if i < 0 {
		i = 0
	}
	if i >= len(a) {
		i = len(a) - 1
	}
	return a[i]
}
func impairmentDial(socks, target string) (net.Conn, error) {
	d, err := proxy.SOCKS5("tcp", socks, nil, &net.Dialer{Timeout: 12 * time.Second})
	if err != nil {
		return nil, err
	}
	cd, ok := d.(proxy.ContextDialer)
	if !ok {
		return nil, fmt.Errorf("SOCKS dialer has no deadline-capable DialContext")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
	defer cancel()
	return cd.DialContext(ctx, "tcp", target)
}
func impairmentEcho(c net.Conn) error {
	var request [73]byte
	request[0] = 'P'
	copy(request[9:], payload[:64])
	var reply [64]byte
	if err := writeAll(c, request[:]); err != nil {
		return err
	}
	if _, err := io.ReadFull(c, reply[:]); err != nil {
		return err
	}
	for i := range reply {
		if reply[i] != payload[i] {
			return fmt.Errorf("echo mismatch")
		}
	}
	return nil
}
func impairmentChunk(c net.Conn, op byte, buf []byte) error {
	var request [9]byte
	request[0] = op
	binary.BigEndian.PutUint64(request[1:], uint64(len(payload)))
	if err := writeAll(c, request[:]); err != nil {
		return err
	}
	if op == 'D' {
		if _, err := io.ReadFull(c, buf); err != nil {
			return err
		}
		if crc32.Checksum(buf, crcTable) != expectedCRC {
			return fmt.Errorf("payload CRC mismatch")
		}
	} else {
		if err := writeAll(c, payload); err != nil {
			return err
		}
	}
	var ack [12]byte
	if _, err := io.ReadFull(c, ack[:]); err != nil {
		return err
	}
	if binary.BigEndian.Uint64(ack[:8]) != uint64(len(payload)) || binary.BigEndian.Uint32(ack[8:]) != expectedCRC {
		return fmt.Errorf("receiver byte count/CRC mismatch")
	}
	return nil
}

func impairmentBoundaryTimeout(err error, end, now time.Time) bool {
	var timeout net.Error
	return errors.As(err, &timeout) && timeout.Timeout() && !now.Before(end.Add(-20*time.Millisecond))
}

// Keep up to 1 MiB per flow in flight without an application stop-and-wait
// round trip every 64 KiB. Only receiver-confirmed, CRC-verified blocks count.
func impairmentPipeline(c net.Conn, op byte, end time.Time) (count int64, result error) {
	c.SetDeadline(end)
	permits := make(chan struct{}, 16)
	stop := make(chan struct{})
	writerDone := make(chan error, 1)
	go func() {
		var request [9]byte
		request[0] = op
		binary.BigEndian.PutUint64(request[1:], uint64(len(payload)))
		for time.Now().Before(end) {
			select {
			case permits <- struct{}{}:
			case <-stop:
				writerDone <- nil
				return
			}
			if err := writeAll(c, request[:]); err != nil {
				writerDone <- err
				return
			}
			if op == 'U' {
				if err := writeAll(c, payload); err != nil {
					writerDone <- err
					return
				}
			}
		}
		writerDone <- nil
	}()
	defer func() {
		close(stop)
		c.SetWriteDeadline(time.Now())
		writeErr := <-writerDone
		if writeErr != nil && !impairmentBoundaryTimeout(writeErr, end, time.Now()) && (result == nil || impairmentBoundaryTimeout(result, end, time.Now())) {
			result = fmt.Errorf("pipeline writer: %w", writeErr)
		}
	}()
	buf := make([]byte, len(payload))
	for time.Now().Before(end) {
		if op == 'D' {
			if _, err := io.ReadFull(c, buf); err != nil {
				return count, err
			}
			if crc32.Checksum(buf, crcTable) != expectedCRC {
				return count, fmt.Errorf("pipeline payload CRC mismatch")
			}
		}
		var ack [12]byte
		if _, err := io.ReadFull(c, ack[:]); err != nil {
			return count, err
		}
		if binary.BigEndian.Uint64(ack[:8]) != uint64(len(payload)) || binary.BigEndian.Uint32(ack[8:]) != expectedCRC {
			return count, fmt.Errorf("pipeline receiver count/CRC mismatch")
		}
		select {
		case <-permits:
		default:
			return count, fmt.Errorf("unsolicited pipeline acknowledgment")
		}
		count += int64(len(payload))
	}
	return count, nil
}
func measureImpairment(p profile, target string, s impairmentScenario, round int, op byte, duration time.Duration, seed, streams int, pipeline bool) impairmentRow {
	r := impairmentRow{Protocol: p.name, Round: round, Direction: string(op), Streams: streams}
	var conns []net.Conn
	defer func() {
		for _, c := range conns {
			c.Close()
		}
	}()
	setup := time.Now()
	latency, err := impairmentDial(p.socks, target)
	if err != nil {
		r.Errors = append(r.Errors, "cold dial: "+err.Error())
		return r
	}
	conns = append(conns, latency)
	latency.SetDeadline(time.Now().Add(12 * time.Second))
	if err = impairmentEcho(latency); err != nil {
		r.Errors = append(r.Errors, "cold echo: "+err.Error())
		return r
	}
	r.SetupMS = float64(time.Since(setup)) / float64(time.Millisecond)
	var unloaded []float64
	for range 9 {
		latency.SetDeadline(time.Now().Add(5 * time.Second))
		t := time.Now()
		if err = impairmentEcho(latency); err != nil {
			r.Errors = append(r.Errors, "idle echo: "+err.Error())
			return r
		}
		unloaded = append(unloaded, float64(time.Since(t))/float64(time.Millisecond))
	}
	r.UnloadedP50 = impairmentPercentile(unloaded, .5)
	for range r.Streams {
		c, e := impairmentDial(p.socks, target)
		if e != nil {
			r.Errors = append(r.Errors, "load dial: "+e.Error())
			return r
		}
		conns = append(conns, c)
		c.SetDeadline(time.Now().Add(10 * time.Second))
		if e = impairmentEcho(c); e != nil {
			r.Errors = append(r.Errors, "load prime: "+e.Error())
			return r
		}
	}
	start := time.Now()
	end := start.Add(duration)
	beforeCPU, _ := processStats(p.pids)
	var wg sync.WaitGroup
	var lock sync.Mutex
	for _, c := range conns[1:] {
		wg.Add(1)
		go func(c net.Conn) {
			defer wg.Done()
			if pipeline {
				count, e := impairmentPipeline(c, op, end)
				lock.Lock()
				r.Bytes += count
				if e != nil && !impairmentBoundaryTimeout(e, end, time.Now()) {
					r.Errors = append(r.Errors, e.Error())
				}
				lock.Unlock()
				return
			}
			buf := make([]byte, len(payload))
			c.SetDeadline(end)
			for time.Now().Before(end) {
				e := impairmentChunk(c, op, buf)
				if e != nil {
					if !impairmentBoundaryTimeout(e, end, time.Now()) {
						lock.Lock()
						r.Errors = append(r.Errors, e.Error())
						lock.Unlock()
					}
					return
				}
				lock.Lock()
				r.Bytes += int64(len(payload))
				lock.Unlock()
			}
		}(c)
	}
	outageDone := make(chan impairmentOutage, 1)
	if s.Blackout {
		go func() {
			time.Sleep(3 * time.Second)
			event := impairmentOutage{StartMS: float64(time.Since(start)) / float64(time.Millisecond)}
			for _, dev := range []string{"bench-c", "bench-s"} {
				if e := impairmentLeaf(dev, s, true, seed); e != nil {
					event.Error += e.Error()
				}
			}
			time.Sleep(2 * time.Second)
			event.During = impairmentQdisc()
			for _, dev := range []string{"bench-c", "bench-s"} {
				if e := impairmentLeaf(dev, s, false, seed+1000); e != nil {
					event.Error += e.Error()
				}
			}
			event.EndMS = float64(time.Since(start)) / float64(time.Millisecond)
			outageDone <- event
		}()
	}
	for time.Now().Before(end) {
		t := time.Now()
		deadline := t.Add(5 * time.Second)
		if deadline.After(end) {
			deadline = end
		}
		latency.SetDeadline(deadline)
		e := impairmentEcho(latency)
		if e != nil {
			var timeout net.Error
			if errors.As(e, &timeout) && timeout.Timeout() {
				r.Timeouts++
			}
			if !impairmentBoundaryTimeout(e, end, time.Now()) {
				lock.Lock()
				r.Errors = append(r.Errors, "loaded echo: "+e.Error())
				lock.Unlock()
			}
			break
		}
		r.Pings = append(r.Pings, impairmentPing{float64(t.Sub(start)) / float64(time.Millisecond), float64(time.Since(t)) / float64(time.Millisecond)})
		remaining := time.Until(end)
		if remaining > 100*time.Millisecond {
			time.Sleep(100 * time.Millisecond)
		} else if remaining > 0 {
			time.Sleep(remaining)
		}
	}
	wg.Wait()
	r.Seconds = time.Since(start).Seconds()
	afterCPU, _ := processStats(p.pids)
	r.CPU = (afterCPU - beforeCPU) / r.Seconds
	r.Mbps = float64(r.Bytes) * 8 / r.Seconds / 1e6
	var loaded []float64
	for _, ping := range r.Pings {
		loaded = append(loaded, ping.RTTMS)
	}
	r.LoadedP50 = impairmentPercentile(loaded, .5)
	r.LoadedP95 = impairmentPercentile(loaded, .95)
	r.LoadedP99 = impairmentPercentile(loaded, .99)
	if s.Blackout {
		event := <-outageDone
		r.Outage = &event
		if event.Error != "" {
			r.Errors = append(r.Errors, event.Error)
		}
		for _, ping := range r.Pings {
			if ping.SentMS >= event.EndMS {
				r.Recovered = true
				r.RecoveryMS = ping.SentMS + ping.RTTMS - event.EndMS
				break
			}
		}
	}
	r.Qdisc = impairmentQdisc()
	return r
}

func runImpairment(name, out, server, client, xray string, seconds float64, rounds, streams int, pipeline bool) error {
	if err := isolatedNetwork(); err != nil {
		return err
	}
	s, err := impairmentConfig(name)
	if err != nil {
		return err
	}
	if seconds < 6 || seconds > 60 || rounds < 1 || rounds > 10 {
		return fmt.Errorf("use duration 6..60 seconds and 1..10 rounds")
	}
	if streams != 1 && streams != 4 {
		return fmt.Errorf("bulk flow count must be 1 or 4")
	}
	self, _ := os.Readlink("/proc/self/ns/net")
	host, _ := os.Readlink("/proc/1/ns/net")
	seen := map[string]bool{self: true, host: true}
	for _, v := range []struct {
		name string
		dest *string
	}{{"ATLANT_BENCH_CLIENT_NETNS_PID", &benchmarkClientNamespace}, {"ATLANT_BENCH_SERVER_NETNS_PID", &benchmarkServerNamespace}} {
		pid := os.Getenv(v.name)
		n, e := strconv.Atoi(pid)
		if e != nil || n < 2 {
			return fmt.Errorf("invalid child namespace PID")
		}
		ns, e := os.Readlink("/proc/" + pid + "/ns/net")
		if e != nil || seen[ns] {
			return fmt.Errorf("client/server must have distinct child network namespaces")
		}
		seen[ns] = true
		*v.dest = pid
	}
	if server == "" || client == "" {
		return fmt.Errorf("server and client binaries required")
	}
	for _, binary := range []string{server, client} {
		if _, e := os.Stat(binary); e != nil {
			return e
		}
	}
	if err = os.Mkdir(out, 0700); err != nil {
		return err
	}
	out, err = filepath.Abs(out)
	if err != nil {
		return err
	}
	benchmarkServerPort = impairmentPort
	benchmarkServerHost = "10.200.2.2"
	benchmarkClientHost = "10.200.1.2"
	if _, err = rand.Read(payload); err != nil {
		return err
	}
	expectedCRC = crc32.Checksum(payload, crcTable)
	target, err := net.Listen("tcp", "192.0.2.1:0")
	if err != nil {
		return err
	}
	defer target.Close()
	go serveTarget(target)
	donor, certPath, keyPath := "", "", ""
	if xray != "" {
		var stop func()
		donor, certPath, keyPath, stop, err = startImpairmentDonor(out, "192.0.2.1")
		if err != nil {
			return err
		}
		defer stop()
	}
	report := impairmentReport{MeasurementVersion: 2, Started: time.Now(), Scenario: s, Protection: benchmarkProtection, Notes: []string{
		"Only generated local data; separate client/router/server network namespaces, no WAN. Netem on forwarded packets at router egress toward receiver, not at TCP sender.",
		"MTU 1500 and GSO/GRO/TSO disabled only on throwaway veths; production transport flags unchanged. Rate 20Mbps per direction; random loss per direction, normal delay jitter can reorder packets.",
		fmt.Sprintf("Impairment filters apply only to TCP/UDP tunnel port 44330; SOCKS, RAM target, and management traffic are not impaired. %d bulk flows plus a separate reliable echo flow.", streams),
		"Every result uses fresh processes/transport sessions. Useful throughput counts only complete 64KiB CRC-verified batches; partial final batches excluded. Inner application TLS not used.",
		"Cold first echo includes tunnel setup/auth. Loaded echo p50/p95/p99 are application RTT, not ICMP. End-of-window timeout is censored; raw samples and timeout count retained.",
		"Blackout means both tunnel directions drop 100% for approximately two seconds, not WiFi/LTE address migration. Recovery is first echo sent after restore on the same connection.",
		"Protection requested exactly as in existing harness; Linux activeCfg padding limitation still applies. Default QUIC pacing config has no bandwidth cap; emulated link sets the cap.",
	}}
	report.GoVersion = runtime.Version()
	if xray != "" {
		version, err := exec.Command(xray, "version").Output()
		if err != nil {
			return err
		}
		report.XrayVersion = strings.TrimSpace(string(version))
	}
	if pipeline {
		report.MeasurementVersion = 3
		report.Notes = append(report.Notes, "Bulk requests pipelined: up to 16 unacknowledged 64KiB blocks (1MiB) per flow; no per-block stop-and-wait. Only confirmed blocks count.")
	} else {
		report.Notes = append(report.Notes, "Application workload is stop-and-wait per 64KiB block; throughput is not an unrestricted bulk-stream ceiling.")
	}
	names := []string{"atlant-reality", "atlant-xhttp", "atlant-quic"}
	if xray != "" {
		names = append(names, "vless-reality-vision", "vless-xhttp-reality")
	}
	if benchmarkProtocolFilter != "" {
		selected := names[:0]
		for _, name := range names {
			if strings.Contains(","+benchmarkProtocolFilter+",", ","+name+",") {
				selected = append(selected, name)
			}
		}
		if len(selected) == 0 {
			return fmt.Errorf("no matching impairment protocols")
		}
		names = selected
	}
	for round := 1; round <= rounds; round++ {
		for i := range names {
			name := names[(i+round-1)%len(names)]
			for _, op := range []byte{'D', 'U'} {
				seed := 100 + round*10 + int(op)
				if err = configureImpairment(s, seed); err != nil {
					return err
				}
				p, e := startProfile(name, out, server, client, xray, donor, certPath, keyPath, target.Addr().String(), target.Addr().String())
				var result impairmentRow
				if e != nil {
					result = impairmentRow{Protocol: name, Round: round, Direction: string(op), Streams: streams, Errors: []string{e.Error()}}
				} else {
					result = measureImpairment(p, target.Addr().String(), s, round, op, time.Duration(seconds*float64(time.Second)), seed, streams, pipeline)
					p.cleanup()
				}
				if result.Qdisc == "" {
					result.Qdisc = impairmentQdisc()
				}
				report.Results = append(report.Results, result)
				writeJSON(filepath.Join(out, "results.json"), report)
				fmt.Printf("%s r%d %s %c %.2f Mbps idle %.1f loaded p50/p95 %.1f/%.1f ms cold %.1f recovered=%v errors=%v\n", name, round, s.Name, op, result.Mbps, result.UnloadedP50, result.LoadedP50, result.LoadedP95, result.SetupMS, result.Recovered, result.Errors)
				if e != nil {
					return fmt.Errorf("isolated fixture setup failed: %w", e)
				}
			}
		}
	}
	for _, result := range report.Results {
		if len(result.Errors) != 0 {
			return fmt.Errorf("impairment verification has failing cases")
		}
	}
	return nil
}
