#!/bin/sh
set -eu
# Always run with: unshare -n -- sh this-script PROJECT_DIR NEW_OUTPUT SCENARIO [SECONDS] [ROUNDS]
if [ "$(readlink /proc/self/ns/net)" = "$(readlink /proc/1/ns/net)" ]; then
  printf '%s\n' 'Refusing to change the primary network namespace.' >&2
  exit 1
fi
project_dir=$1
output_dir=$2
scenario=$3
seconds=${4:-8}
rounds=${5:-2}
streams=${6:-4}
pipeline=${7:-false}
client_pid=
server_pid=
cleanup() {
  if [ -n "$client_pid" ]; then kill "$client_pid" 2>/dev/null || true; wait "$client_pid" 2>/dev/null || true; fi
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
}
trap cleanup EXIT HUP INT TERM
cd "$project_dir"
unshare -n -- sleep 86400 &
client_pid=$!
unshare -n -- sleep 86400 &
server_pid=$!
# Wait for unshare to enter the child namespaces before moving any interface.
for child_pid in "$client_pid" "$server_pid"; do
  attempts=0
  while [ "$(readlink /proc/"$child_pid"/ns/net)" = "$(readlink /proc/self/ns/net)" ]; do
    attempts=$((attempts + 1))
    if [ "$attempts" -gt 100 ]; then echo 'Child namespace did not start' >&2; exit 1; fi
    sleep 0.01
  done
done
ip link set lo up
ip addr add 192.0.2.1/32 dev lo
ip link add bench-c type veth peer name peer-c
ip link add bench-s type veth peer name peer-s
ip link set peer-c netns "$client_pid"
ip link set peer-s netns "$server_pid"
ip addr add 10.200.1.1/24 dev bench-c
ip addr add 10.200.2.1/24 dev bench-s
for interface in bench-c bench-s; do
  ip link set "$interface" mtu 1500 up
  ethtool -K "$interface" tso off gso off gro off >/dev/null
done
for side in c s; do
  if [ "$side" = c ]; then ns_pid=$client_pid; subnet=1; else ns_pid=$server_pid; subnet=2; fi
  nsenter -t "$ns_pid" -n -- ip link set lo up
  nsenter -t "$ns_pid" -n -- ip link set "peer-$side" mtu 1500 up
  nsenter -t "$ns_pid" -n -- ip addr add "10.200.$subnet.2/24" dev "peer-$side"
  nsenter -t "$ns_pid" -n -- ip route add default via "10.200.$subnet.1"
  nsenter -t "$ns_pid" -n -- ethtool -K "peer-$side" tso off gso off gro off >/dev/null
done
# This sysctl belongs only to the throwaway router namespace, not WSL's host.
sysctl -q -w net.ipv4.ip_forward=1
export ATLANT_BENCH_CLIENT_NETNS_PID=$client_pid
export ATLANT_BENCH_SERVER_NETNS_PID=$server_pid
"${ATLANT_BENCH_TOOL:-artifacts/tools/localbench}" \
  -impairment "$scenario" -only "${ATLANT_BENCH_ONLY:-}" -impairment-streams "$streams" -impairment-pipeline="$pipeline" -out "$output_dir" -seconds "$seconds" -rounds "$rounds" \
  -server "${ATLANT_BENCH_SERVER:-$project_dir/artifacts/current/atlant-server-linux-amd64}" \
  -client "${ATLANT_BENCH_CLIENT:-$project_dir/artifacts/current/atlant-linux-amd64}" \
  -xray "${ATLANT_BENCH_XRAY:-}" -protection=true
