package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

func median(v []float64) float64 {
	sort.Float64s(v)
	n := len(v)
	if n == 0 {
		return 0
	}
	if n%2 == 0 {
		return (v[n/2-1] + v[n/2]) / 2
	}
	return v[n/2]
}
func summarize(path string) error {
	data, e := os.ReadFile(path)
	if e != nil {
		return e
	}
	var rep report
	if e = json.Unmarshal(data, &rep); e != nil {
		return e
	}
	var s strings.Builder
	fmt.Fprintf(&s, "# Локальное сравнение ядер VPN\n\nНачало: %s. %s/%s, %s, %d логических CPU.\n\n", rep.Started, rep.OS, rep.Arch, rep.GoVersion, rep.CPUs)
	fmt.Fprintf(&s, "Xray: `%s`.\n\n", strings.TrimSpace(strings.Split(rep.XrayVersion, "\n")[0]))
	fmt.Fprintf(&s, "## Методика\n\nВсе участники работают на одном ноутбуке в Linux WSL2, внутри отдельного network namespace без WAN-интерфейсов. Тестовая цель %s назначена только его loopback, поэтому защита Atlant от SSRF не отключалась. Если выбран kernel WireGuard, в изолированном стенде создаётся ещё один namespace с сервером; зашифрованный UDP остаётся на loopback исходного namespace. Системные маршруты Windows и основного WSL не изменяются.\n\n", rep.TargetHost)
	fmt.Fprintf(&s, "Atlant wire=%d, protection=%v, disable_pacer=%v. Версия Go Atlant: %s.\n\n", rep.WireVersion, rep.Protection, rep.DisablePacer, rep.GoVersion)
	fmt.Fprintf(&s, "QUIC client processes: %d (4 — диагностический вариант, не production pool). UDP buffer limits: %v. Счётчики UDP в results.json охватывают setup/warmup/sample внутри изолированного namespace.\n\n", rep.QUICClientProcesses, rep.UDPBufferLimits)
	fmt.Fprintf(&s, "Полезная нагрузка — повторяемые случайные блоки 64 KiB в RAM; партии %d MiB. Для каждой партии проверяются точное число принятых байт и CRC32C. Нет файлового или интернет-трафика в измеряемом пути. Короткий handshake, прогрев и 31 RTT-проба исключены из throughput. Каждый замер не короче %.1f с; в таблицах медиана независимых повторений. Порядок протоколов ротируется между раундами. Периодические служебные записи конфигурации/логов возможны, полезные данные на диск не пишутся.\n\n", rep.BatchBytes/1048576, rep.DurationSeconds)
	s.WriteString("Atlant — настоящие сервер и Linux-клиент; дополнительные padding/chaffing задаются флагом protection (см. results.json); mux и лимиты скорости отключены. Использован исправленный SOCKS→QUIC адаптер. VLESS — официальный Xray, отдельные клиент и сервер, TCP/RAW: без защиты, TLS, REALITY+xtls-rprx-vision. TLS-сертификат стенда проверяется по fingerprint; внутренний TLS 1.3 проверяется тестовым trust store. Для включённых в запуск WG-строк: WireGuard-go — настоящий модуль wireguard-go, два gVisor TCP/IP-стека и SOCKS-мост; kernel WireGuard — настоящий драйвер ядра WSL и TCP/IP ядра, с MTU 1420.\n\n")
	names := []string{"direct", "atlant-reality", "atlant-xhttp", "atlant-quic", "vless-raw", "vless-tls", "vless-reality-vision", "vless-xhttp-reality", "vless-xhttp-tls", "wireguard-go", "wireguard-kernel"}
	var total int64
	failures := []row{}
	for _, r := range rep.Results {
		total += r.Bytes
		if r.Error != "" {
			failures = append(failures, r)
		}
	}
	fmt.Fprintf(&s, "Завершённых записей: %d; ошибок: %d; проверенной полезной нагрузки: %.2f GiB (без прогрева).\n\n", len(rep.Results), len(failures), float64(total)/(1<<30))
	if len(rep.ExcludedResults) > 0 {
		fmt.Fprintf(&s, "Отдельно сохранены %d ошибки запуска стенда; неудачный запуск не записан как нулевая скорость. После исправления ожидания готовности повторён только этот протокол/раунд. Исходные файлы: %v. Изменение ожидания касается фазы ДО замера, алгоритм передачи не менялся.\n\n", len(rep.ExcludedResults), rep.SupplementPaths)
		for _, r := range rep.ExcludedResults {
			fmt.Fprintf(&s, "- %s, раунд %d: `%s`.\n", r.Protocol, r.Round, r.Error)
		}
		s.WriteString("\n")
	}
	for _, inner := range []bool{false, true} {
		label := "Без внутреннего TLS (но с защитой самого транспорта, кроме vless-raw)"
		if inner {
			label = "Внутренний TLS 1.3 — модель HTTPS-нагрузки, включая оптимизацию Vision"
		}
		fmt.Fprintf(&s, "## %s\n\n", label)
		for _, streams := range []int{1, 4} {
			fmt.Fprintf(&s, "### Потоков: %d\n\n| Реализация | Скачать, Мбит/с [min…max] | Отправить, Мбит/с [min…max] | RTT, мс |\n|---|---:|---:|---:|\n", streams)
			for _, name := range names {
				downs, ups, rtts := []float64{}, []float64{}, []float64{}
				for _, r := range rep.Results {
					if r.Protocol == name && r.InnerTLS == inner && r.Streams == streams && r.Error == "" {
						rtts = append(rtts, r.RTTMedianMS)
						if r.Direction == "D" {
							downs = append(downs, r.Mbps)
						} else if r.Direction == "U" {
							ups = append(ups, r.Mbps)
						}
					}
				}
				cell := func(v []float64) string {
					if len(v) == 0 {
						return "—"
					}
					m := median(v)
					return fmt.Sprintf("%.0f [%.0f…%.0f] (n=%d)", m, v[0], v[len(v)-1], len(v))
				}
				fmt.Fprintf(&s, "| %s | %s | %s | %.3f |\n", name, cell(downs), cell(ups), median(rtts))
			}
			s.WriteString("\n")
		}
	}
	s.WriteString("## CPU и память — 1 поток, внутренняя TLS-нагрузка\n\nCPU — сумма CPU-времени тестера/цели, клиента и сервера из procfs; 1.0 = одно занятое ядро. RSS — сумма resident memory этих процессов в конце замера, не peak и не чистые расходы протокола. Kernel WireGuard исключён: procfs процессов не учитывает все затраты kernel workers.\n\n| Реализация | CPU-ядер, download | CPU-с/ГиБ download | RSS, МиБ download |\n|---|---:|---:|---:|\n")
	for _, name := range names {
		cores, cost, rss := []float64{}, []float64{}, []float64{}
		for _, r := range rep.Results {
			if r.Protocol == name && r.InnerTLS && r.Streams == 1 && r.Direction == "D" && r.Error == "" && r.CPUSeconds >= 0 && r.Bytes > 0 {
				cores = append(cores, r.AverageCores)
				cost = append(cost, r.CPUSeconds/(float64(r.Bytes)/(1<<30)))
				rss = append(rss, r.RSSMiB)
			}
		}
		if len(cores) == 0 {
			fmt.Fprintf(&s, "| %s | — | — | — |\n", name)
		} else {
			fmt.Fprintf(&s, "| %s | %.2f | %.2f | %.1f |\n", name, median(cores), median(cost), median(rss))
		}
	}
	s.WriteString("\n## Ограничения\n\n- Это результаты конкретного ноутбука, WSL2 и конфигураций, а не универсальная скорость протокола. Фоновые программы пользователя не отключались, частоты CPU не фиксировались. Учитывайте min/max.\n- Версии сборок указаны выше и в results.json; компиляторы участников могут отличаться. Это сравнение реализаций, не изолированный эксперимент с одним компилятором.\n- VLESS raw не шифрует внешний транспорт; его нельзя объявлять равнозначным по безопасности. Внутренняя TLS-нагрузка не добавляет защиту произвольному нет TLS трафику.\n- Kernel WireGuard обрабатывает каждый IP-пакет и использует MTU 1420. Стрим-прокси используют большие TCP-буферы. В WSL это разные пути обработки и разная цена виртуализации. Результат не доказывает превосходство Atlant над WireGuard в реальной сети.\n- RTT измеряется без нагрузки, не показывает задержки под нагрузкой. Setup включает SOCKS/внутренний TLS, но установление внешнего QUIC/WG может переиспользоваться.\n- Не измерены WAN RTT, потери, jitter, UDP goodput, мобильная батарея, DPI/ТСПУ и Android TUN. Данный тест не определяет, какой VPN «лучше вообще».\n")
	if len(failures) > 0 {
		s.WriteString("\n## Ошибки\n\n")
		for _, r := range failures {
			fmt.Fprintf(&s, "- %s r%d TLS=%v streams=%d direction=%s: %s\n", r.Protocol, r.Round, r.InnerTLS, r.Streams, r.Direction, r.Error)
		}
	}
	return os.WriteFile(filepath.Join(filepath.Dir(path), "REPORT.md"), []byte(s.String()), 0600)
}

func mergeReports(basePath, extraPath, outPath string) error {
	read := func(p string) (report, error) {
		var r report
		b, e := os.ReadFile(p)
		if e != nil {
			return r, e
		}
		e = json.Unmarshal(b, &r)
		return r, e
	}
	base, e := read(basePath)
	if e != nil {
		return e
	}
	extra, e := read(extraPath)
	if e != nil {
		return e
	}
	if len(extra.Results) != 8 {
		return fmt.Errorf("retry must contain exactly 8 cases")
	}
	name, round := extra.Results[0].Protocol, extra.Results[0].Round
	if name != "wireguard-kernel" || extra.DurationSeconds != base.DurationSeconds {
		return fmt.Errorf("unexpected retry configuration")
	}
	for _, r := range extra.Results {
		if r.Error != "" || r.Protocol != name || r.Round != round {
			return fmt.Errorf("retry contains errors or mixed protocols/rounds")
		}
	}
	kept := []row{}
	found := false
	for _, r := range base.Results {
		if r.Protocol == name && r.Round == round {
			if r.Error == "" || r.Bytes != 0 {
				return fmt.Errorf("refusing to discard successful measurement")
			}
			base.ExcludedResults = append(base.ExcludedResults, r)
			found = true
		} else {
			kept = append(kept, r)
		}
	}
	if !found {
		return fmt.Errorf("no failed startup to supplement")
	}
	base.Results = append(kept, extra.Results...)
	base.SupplementPaths = []string{basePath, extraPath}
	if len(base.Results) != 216 {
		return fmt.Errorf("combined report must contain 216 cases")
	}
	keys := map[string]int{}
	for _, r := range base.Results {
		if r.Error != "" {
			return fmt.Errorf("remaining data errors")
		}
		key := fmt.Sprintf("%s/%v/%d/%s/%d", r.Protocol, r.InnerTLS, r.Streams, r.Direction, r.Round)
		keys[key]++
	}
	if len(keys) != 216 {
		return fmt.Errorf("duplicate benchmark cases")
	}
	writeJSON(outPath, base)
	return nil
}
