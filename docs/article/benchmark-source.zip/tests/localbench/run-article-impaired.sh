#!/bin/sh
set -eu
if [ "$(readlink /proc/self/ns/net)" = "$(readlink /proc/1/ns/net)" ] ||
   [ "$(readlink /proc/self/ns/mnt)" = "$(readlink /proc/1/ns/mnt)" ]; then
  printf '%s\n' 'Run through unshare -mn; refusing the primary namespaces.' >&2
  exit 1
fi
project_dir=$1
result_dir=$2
binary_dir=$3
scenario=${4:-rtt100-loss3}
rounds=${5:-2}
if [ -e "$result_dir" ]; then
  printf '%s\n' 'Choose a new result directory.' >&2
  exit 1
fi
mount --make-rprivate /
mount --bind "$project_dir/tests/localbench/article-hosts" /etc/hosts
export ATLANT_BENCH_TOOL="$binary_dir/localbench-impaired"
export ATLANT_BENCH_SERVER="$binary_dir/atlant-server"
export ATLANT_BENCH_CLIENT="$binary_dir/atlant-client"
export ATLANT_BENCH_XRAY="$project_dir/artifacts/tools/xray-26.3.27/xray"
export ATLANT_BENCH_WIRE_VERSION=7
exec sh "$project_dir/tests/localbench/run-impaired.sh" \
  "$project_dir" "$result_dir" "$scenario" 8 "$rounds" 4 true
