#!/bin/sh
set -eu
# Only disposable network namespaces: never change host routes or VPN adapters.
if [ "$(readlink /proc/self/ns/net)" = "$(readlink /proc/1/ns/net)" ] ||
   [ "$(readlink /proc/self/ns/mnt)" = "$(readlink /proc/1/ns/mnt)" ]; then
  printf '%s\n' 'Run through unshare -mn; refusing the primary namespaces.' >&2
  exit 1
fi
project_dir=$1
result_dir=$2
binary_dir=$3
only=${4:-direct,atlant-reality,atlant-xhttp,atlant-quic,vless-reality-vision,vless-xhttp-reality}
seconds=${5:-2}
rounds=${6:-3}
cd "$project_dir"
if [ -e "$result_dir" ]; then
  printf '%s\n' 'Choose a new result directory; previous measurements are retained.' >&2
  exit 1
fi
mount --make-rprivate /
# This mount is visible only inside the disposable mount namespace. The real
# Windows/WSL hosts files and DNS settings are never edited.
mount --bind "$project_dir/tests/localbench/article-hosts" /etc/hosts
ip link set lo up
ip address add 192.0.2.1/32 dev lo
export ATLANT_BENCH_WIRE_VERSION=7
exec "$binary_dir/localbench" \
  -target-host 192.0.2.1 \
  -server "$binary_dir/atlant-server" \
  -client "$binary_dir/atlant-client" \
  -xray "$project_dir/artifacts/tools/xray-26.3.27/xray" \
  -only "$only" \
  -protection=true -disable-pacer=false -quic-client-processes 1 \
  -out "$result_dir" -seconds "$seconds" -rounds "$rounds"
