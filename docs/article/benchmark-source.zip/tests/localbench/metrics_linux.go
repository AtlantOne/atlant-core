package main

import (
	"os"
	"strconv"
	"strings"
)

func readUDPCounters() map[string]uint64 {
	data, err := os.ReadFile("/proc/net/snmp")
	if err != nil {
		return nil
	}
	return parseUDPCounters(string(data))
}

func parseUDPCounters(data string) map[string]uint64 {
	lines := strings.Split(data, "\n")
	for i := 0; i+1 < len(lines); i++ {
		if !strings.HasPrefix(lines[i], "Udp:") || !strings.HasPrefix(lines[i+1], "Udp:") {
			continue
		}
		header, values := strings.Fields(lines[i]), strings.Fields(lines[i+1])
		if len(header) != len(values) {
			return nil
		}
		out := make(map[string]uint64)
		for j := 1; j < len(header); j++ {
			v, err := strconv.ParseUint(values[j], 10, 64)
			if err != nil {
				return nil
			}
			out[header[j]] = v
		}
		return out
	}
	return nil
}

func udpCounterDelta(before, after map[string]uint64) map[string]uint64 {
	if before == nil || after == nil {
		return nil
	}
	out := make(map[string]uint64)
	for key, value := range after {
		if old, ok := before[key]; ok && value >= old {
			out[key] = value - old
		}
	}
	return out
}

func udpBufferLimits() map[string]uint64 {
	out := make(map[string]uint64)
	for _, name := range []string{"rmem_max", "wmem_max", "rmem_default", "wmem_default"} {
		data, err := os.ReadFile("/proc/sys/net/core/" + name)
		if err != nil {
			continue
		}
		value, err := strconv.ParseUint(strings.TrimSpace(string(data)), 10, 64)
		if err == nil {
			out[name] = value
		}
	}
	return out
}

// Linux procfs reports task CPU in USER_HZ ticks (100 on the tested WSL kernel).
func processStats(pids []int) (float64, float64) {
	cpu, rss := 0.0, 0.0
	for _, pid := range pids {
		b, e := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/stat")
		if e != nil {
			continue
		}
		s := string(b)
		i := strings.LastIndex(s, ") ")
		if i < 0 {
			continue
		}
		f := strings.Fields(s[i+2:])
		if len(f) > 21 {
			u, _ := strconv.ParseFloat(f[11], 64)
			sy, _ := strconv.ParseFloat(f[12], 64)
			cpu += (u + sy) / 100
			pages, _ := strconv.ParseFloat(f[21], 64)
			rss += pages * float64(os.Getpagesize()) / 1048576
		}
	}
	return cpu, rss
}
