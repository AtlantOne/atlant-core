package main

import (
	"crypto/ecdh"
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"net/netip"
	"os"
	"strconv"

	"golang.zx2c4.com/wireguard/conn"
	"golang.zx2c4.com/wireguard/device"
	"golang.zx2c4.com/wireguard/tun/netstack"
)

func udpPort() int {
	l, e := net.ListenPacket("udp", "127.0.0.1:0")
	must(e)
	defer l.Close()
	return l.LocalAddr().(*net.UDPAddr).Port
}

func startWireGuard(name, plain, secure string) (profile, error) {
	ckey, e := ecdh.X25519().GenerateKey(rand.Reader)
	if e != nil {
		return profile{}, e
	}
	skey, e := ecdh.X25519().GenerateKey(rand.Reader)
	if e != nil {
		return profile{}, e
	}
	ct, cn, e := netstack.CreateNetTUN([]netip.Addr{netip.MustParseAddr("10.77.0.1")}, nil, 1420)
	if e != nil {
		return profile{}, e
	}
	st, sn, e := netstack.CreateNetTUN([]netip.Addr{netip.MustParseAddr("10.77.0.2")}, nil, 1420)
	if e != nil {
		ct.Close()
		return profile{}, e
	}
	cd := device.NewDevice(ct, conn.NewDefaultBind(), device.NewLogger(device.LogLevelError, "bench-client: "))
	sd := device.NewDevice(st, conn.NewDefaultBind(), device.NewLogger(device.LogLevelError, "bench-server: "))
	fail := func(err error) (profile, error) { cd.Close(); sd.Close(); return profile{}, err }
	cp, sp := udpPort(), udpPort()
	conf := func(key, peer []byte, port, remote int, allowed string) string {
		return fmt.Sprintf("private_key=%s\nlisten_port=%d\npublic_key=%s\nallowed_ip=%s/32\nendpoint=127.0.0.1:%d\n", hex.EncodeToString(key), port, hex.EncodeToString(peer), allowed, remote)
	}
	if e = cd.IpcSet(conf(ckey.Bytes(), skey.PublicKey().Bytes(), cp, sp, "10.77.0.2")); e != nil {
		return fail(e)
	}
	if e = sd.IpcSet(conf(skey.Bytes(), ckey.PublicKey().Bytes(), sp, cp, "10.77.0.1")); e != nil {
		return fail(e)
	}
	if e = cd.Up(); e != nil {
		return fail(e)
	}
	if e = sd.Up(); e != nil {
		return fail(e)
	}
	var listeners []net.Listener
	for _, target := range []string{plain, secure} {
		_, pt, e := net.SplitHostPort(target)
		if e != nil {
			return fail(e)
		}
		pn, _ := strconv.Atoi(pt)
		l, e := sn.ListenTCP(&net.TCPAddr{IP: net.ParseIP("10.77.0.2"), Port: pn})
		if e != nil {
			for _, v := range listeners {
				v.Close()
			}
			return fail(e)
		}
		listeners = append(listeners, l)
		go func(l net.Listener, target string) {
			for {
				c, e := l.Accept()
				if e != nil {
					return
				}
				go func(c net.Conn) {
					defer c.Close()
					dst, e := net.Dial("tcp", target)
					if e != nil {
						return
					}
					defer dst.Close()
					bridge(c, dst)
				}(c)
			}
		}(l, target)
	}
	sl, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		for _, l := range listeners {
			l.Close()
		}
		return fail(e)
	}
	go func() {
		for {
			c, e := sl.Accept()
			if e != nil {
				return
			}
			go func() {
				defer c.Close()
				target, e := socksRequest(c)
				if e != nil {
					return
				}
				if target != plain && target != secure {
					return
				}
				_, pt, _ := net.SplitHostPort(target)
				dst, e := cn.Dial("tcp", net.JoinHostPort("10.77.0.2", pt))
				if e != nil {
					return
				}
				defer dst.Close()
				if writeAll(c, []byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0}) != nil {
					return
				}
				bridge(c, dst)
			}()
		}
	}()
	return profile{name: name, socks: sl.Addr().String(), pids: []int{os.Getpid()}, cleanup: func() {
		sl.Close()
		for _, l := range listeners {
			l.Close()
		}
		cd.Close()
		sd.Close()
	}}, nil
}
func bridge(a, b net.Conn) {
	done := make(chan struct{})
	go func() { _, _ = io.Copy(a, b); a.Close(); close(done) }()
	_, _ = io.Copy(b, a)
	b.Close()
	<-done
}
func socksRequest(c net.Conn) (string, error) {
	var h [4]byte
	if _, e := io.ReadFull(c, h[:2]); e != nil {
		return "", e
	}
	if h[0] != 5 {
		return "", fmt.Errorf("SOCKS version")
	}
	methods := make([]byte, int(h[1]))
	if _, e := io.ReadFull(c, methods); e != nil {
		return "", e
	}
	if e := writeAll(c, []byte{5, 0}); e != nil {
		return "", e
	}
	if _, e := io.ReadFull(c, h[:]); e != nil {
		return "", e
	}
	if h[0] != 5 || h[1] != 1 {
		return "", fmt.Errorf("SOCKS command")
	}
	n := 4
	switch h[3] {
	case 1:
	case 4:
		n = 16
	case 3:
		if _, e := io.ReadFull(c, h[:1]); e != nil {
			return "", e
		}
		n = int(h[0])
	default:
		return "", fmt.Errorf("SOCKS address")
	}
	b := make([]byte, n)
	if _, e := io.ReadFull(c, b); e != nil {
		return "", e
	}
	var port [2]byte
	if _, e := io.ReadFull(c, port[:]); e != nil {
		return "", e
	}
	host := string(b)
	if h[3] != 3 {
		host = net.IP(b).String()
	}
	return net.JoinHostPort(host, strconv.Itoa(int(binary.BigEndian.Uint16(port[:])))), nil
}
